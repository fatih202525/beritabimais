import { parse as parseCookieHeader } from "cookie";
import { createHash, randomBytes, scrypt as scryptCallback } from "node:crypto";
import { promisify } from "node:util";
import { SignJWT, jwtVerify } from "jose";
import type { Request, Response } from "express";
import type { PortalAccount } from "../drizzle/schema";
import { ENV } from "./_core/env";

const scrypt = promisify(scryptCallback);
export const PORTAL_COOKIE_NAME = "kilas_portal_session";

export type PortalSession = {
  accountId: number;
  username: string;
  displayName: string;
  role: "admin" | "user";
};

export function portalCookieOptions() {
  return { httpOnly: true, path: "/", sameSite: "none" as const, secure: true, maxAge: 1000 * 60 * 60 * 24 * 30 };
}

function secret() {
  return new TextEncoder().encode(ENV.cookieSecret || "kilas-touna-development-secret");
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, encoded: string) {
  if (encoded === "scrypt$demo$kilasbimais") return password === "kilasbimais";
  const [algorithm, salt, digest] = encoded.split("$");
  if (algorithm !== "scrypt" || !salt || !digest) return false;
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  const actual = createHash("sha256").update(derived).digest("hex");
  const expected = createHash("sha256").update(Buffer.from(digest, "hex")).digest("hex");
  return actual === expected;
}

export async function createPortalSession(account: PortalAccount) {
  return new SignJWT({
    accountId: account.id,
    username: account.username,
    displayName: account.displayName,
    role: account.role,
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret());
}

export async function getPortalSession(req: Request): Promise<PortalSession | null> {
  const cookies = parseCookieHeader(req.headers.cookie ?? "");
  const token = cookies[PORTAL_COOKIE_NAME];
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    if (typeof payload.accountId !== "number" || typeof payload.username !== "string" || typeof payload.displayName !== "string" || (payload.role !== "admin" && payload.role !== "user")) return null;
    return { accountId: payload.accountId, username: payload.username, displayName: payload.displayName, role: payload.role };
  } catch {
    return null;
  }
}

export async function setPortalSession(res: Response, token: string) {
  res.cookie(PORTAL_COOKIE_NAME, token, portalCookieOptions());
}

export function clearPortalSession(res: Response) {
  res.clearCookie(PORTAL_COOKIE_NAME, portalCookieOptions());
}
