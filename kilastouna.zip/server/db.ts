import { and, asc, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { articles, InsertUser, mediaAssets, portalAccounts, PortalAccount, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getPortalAccountByUsername(username: string): Promise<PortalAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(portalAccounts).where(eq(portalAccounts.username, username)).limit(1);
  return result[0];
}

export async function getPortalAccountById(id: number): Promise<PortalAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(portalAccounts).where(eq(portalAccounts.id, id)).limit(1);
  return result[0];
}

export async function listPortalAccounts() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: portalAccounts.id, username: portalAccounts.username, displayName: portalAccounts.displayName, role: portalAccounts.role, createdAt: portalAccounts.createdAt }).from(portalAccounts).orderBy(asc(portalAccounts.createdAt));
}

export async function listPublishedArticles(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(articles).where(eq(articles.status, "published")).orderBy(desc(articles.publishedAt), desc(articles.createdAt)).limit(limit);
}

export async function getArticleBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(articles).where(and(eq(articles.slug, slug), eq(articles.status, "published"))).limit(1);
  return result[0];
}

export async function listArticlesForAdmin() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(articles).orderBy(desc(articles.createdAt));
}

export async function listMedia(limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(mediaAssets).orderBy(desc(mediaAssets.createdAt)).limit(limit);
}

export async function seedPortalData() {
  const db = await getDb();
  if (!db) return;

  const existingAdmin = await db.select({ id: portalAccounts.id }).from(portalAccounts).where(eq(portalAccounts.username, "admin")).limit(1);
  if (existingAdmin.length === 0) {
    await db.insert(portalAccounts).values({
      username: "admin",
      passwordHash: "scrypt$demo$kilasbimais",
      displayName: "Administrator Kilas",
      role: "admin",
    });
  }

  const articleCount = await db.select({ count: sql<number>`count(*)` }).from(articles);
  // Seed only on the very first project setup. If an admin later deletes all
  // articles, an application restart must not silently republish demo content.
  if (existingAdmin.length === 0 && Number(articleCount[0]?.count ?? 0) === 0) {
    const now = new Date();
    await db.insert(articles).values([
      {
        slug: "kemenag-touna-perkuat-layanan-bimas-islam",
        title: "Kemenag Touna Perkuat Layanan Bimas Islam di Tengah Masyarakat",
        excerpt: "Kantor Kementerian Agama Kabupaten Tojo Una-Una memperkuat koordinasi layanan Bimas Islam dan KUA agar semakin dekat dengan kebutuhan warga.",
        content: "Penguatan layanan Bimas Islam terus dilakukan melalui koordinasi lintas KUA, pembinaan penyuluh, dan penguatan layanan konsultasi keagamaan. Langkah ini diharapkan menghadirkan pelayanan yang lebih cepat, ramah, dan terukur bagi masyarakat Tojo Una-Una.",
        category: "Bimas Islam",
        imageUrl: "https://images.unsplash.com/photo-1529390079861-591de354faf5?auto=format&fit=crop&w=1400&q=85",
        videoUrl: null,
        authorName: "Redaksi Kilas Touna",
        status: "published",
        publishedAt: now,
      },
      {
        slug: "kua-ampana-kota-buka-konsultasi-keluarga",
        title: "KUA Ampana Kota Buka Ruang Konsultasi Keluarga yang Lebih Inklusif",
        excerpt: "Layanan konsultasi keluarga di KUA Ampana Kota hadir dengan pendekatan yang lebih dialogis dan mudah diakses pasangan muda.",
        content: "KUA Ampana Kota mengembangkan ruang konsultasi keluarga yang terbuka dan inklusif. Penyuluh memberikan pendampingan pra-nikah, komunikasi keluarga, serta rujukan layanan sesuai kebutuhan warga.",
        category: "KUA",
        imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=85",
        videoUrl: null,
        authorName: "Humas KUA Ampana Kota",
        status: "published",
        publishedAt: new Date(now.getTime() - 86400000),
      },
      {
        slug: "penyuluh-agama-touna-bangun-literasi-digital",
        title: "Penyuluh Agama Touna Bangun Literasi Digital untuk Generasi Muda",
        excerpt: "Program literasi digital berbasis nilai keagamaan dibahas dalam pertemuan penyuluh se-Kabupaten Tojo Una-Una.",
        content: "Pertemuan penyuluh agama membahas strategi menghadirkan konten keagamaan yang sejuk, kontekstual, dan dapat dipertanggungjawabkan. Forum ini juga mendorong kolaborasi dengan madrasah, masjid, dan komunitas pemuda.",
        category: "Penyuluh",
        imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=85",
        videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        authorName: "Kontributor Bimas Islam",
        status: "published",
        publishedAt: new Date(now.getTime() - 2 * 86400000),
      },
    ]);
  }
}
