import { TRPCError } from "@trpc/server";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { articles, mediaAssets, portalAccounts } from "../drizzle/schema";
import * as db from "./db";
import { clearPortalSession, createPortalSession, hashPassword, setPortalSession, verifyPassword } from "./portalAuth";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, portalAdminProcedure, portalProcedure, publicProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";

const fallbackArticles = [
  {
    id: 1,
    slug: "kemenag-touna-perkuat-layanan-bimas-islam",
    title: "Kemenag Touna Perkuat Layanan Bimas Islam di Tengah Masyarakat",
    excerpt: "Kantor Kementerian Agama Kabupaten Tojo Una-Una memperkuat koordinasi layanan Bimas Islam dan KUA agar semakin dekat dengan kebutuhan warga.",
    content: "Penguatan layanan Bimas Islam terus dilakukan melalui koordinasi lintas KUA, pembinaan penyuluh, dan penguatan layanan konsultasi keagamaan. Langkah ini diharapkan menghadirkan pelayanan yang lebih cepat, ramah, dan terukur bagi masyarakat Tojo Una-Una.",
    category: "Bimas Islam",
    imageUrl: "https://images.unsplash.com/photo-1529390079861-591de354faf5?auto=format&fit=crop&w=1400&q=85",
    videoUrl: null,
    authorName: "Redaksi Kilas Touna",
    status: "published" as const,
    publishedAt: new Date("2026-10-26T09:00:00.000Z"),
    createdAt: new Date("2026-10-26T09:00:00.000Z"),
    updatedAt: new Date("2026-10-26T09:00:00.000Z"),
  },
  {
    id: 2,
    slug: "kua-ampana-kota-buka-konsultasi-keluarga",
    title: "KUA Ampana Kota Buka Ruang Konsultasi Keluarga yang Lebih Inklusif",
    excerpt: "Layanan konsultasi keluarga di KUA Ampana Kota hadir dengan pendekatan yang lebih dialogis dan mudah diakses pasangan muda.",
    content: "KUA Ampana Kota mengembangkan ruang konsultasi keluarga yang terbuka dan inklusif. Penyuluh memberikan pendampingan pra-nikah, komunikasi keluarga, serta rujukan layanan sesuai kebutuhan warga.",
    category: "KUA",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=85",
    videoUrl: null,
    authorName: "Humas KUA Ampana Kota",
    status: "published" as const,
    publishedAt: new Date("2026-10-25T09:00:00.000Z"),
    createdAt: new Date("2026-10-25T09:00:00.000Z"),
    updatedAt: new Date("2026-10-25T09:00:00.000Z"),
  },
  {
    id: 3,
    slug: "penyuluh-agama-touna-bangun-literasi-digital",
    title: "Penyuluh Agama Touna Bangun Literasi Digital untuk Generasi Muda",
    excerpt: "Program literasi digital berbasis nilai keagamaan dibahas dalam pertemuan penyuluh se-Kabupaten Tojo Una-Una.",
    content: "Pertemuan penyuluh agama membahas strategi menghadirkan konten keagamaan yang sejuk, kontekstual, dan dapat dipertanggungjawabkan. Forum ini juga mendorong kolaborasi dengan madrasah, masjid, dan komunitas pemuda.",
    category: "Penyuluh",
    imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=85",
    videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    authorName: "Kontributor Bimas Islam",
    status: "published" as const,
    publishedAt: new Date("2026-10-24T09:00:00.000Z"),
    createdAt: new Date("2026-10-24T09:00:00.000Z"),
    updatedAt: new Date("2026-10-24T09:00:00.000Z"),
  },
];

const categoryInput = z.string().trim().min(2).max(80);
const articleInput = z.object({
  title: z.string().trim().min(5).max(255),
  excerpt: z.string().trim().min(20).max(1000),
  content: z.string().trim().min(30),
  category: categoryInput,
  imageUrl: z.string().trim().min(1).max(500).refine(value => value.startsWith("https://") || value.startsWith("http://") || value.startsWith("/manus-storage/"), "Foto berita harus berasal dari URL aman atau storage proyek."),
  videoUrl: z.string().url().optional().or(z.literal("")),
  authorName: z.string().trim().min(2).max(120),
  status: z.enum(["draft", "published"]),
});

function slugify(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s-]/g, "").trim().replace(/[\s-]+/g, "-").slice(0, 220);
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    portalMe: publicProcedure.query(({ ctx }) => ctx.portalUser),
    portalLogin: publicProcedure
      .input(z.object({ username: z.string().trim().min(3).max(64), password: z.string().min(6).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const account = await db.getPortalAccountByUsername(input.username.toLowerCase());
        if (!account || !(await verifyPassword(input.password, account.passwordHash))) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Username atau password belum benar." });
        }
        const token = await createPortalSession(account);
        setPortalSession(ctx.res, token);
        return { id: account.id, username: account.username, displayName: account.displayName, role: account.role };
      }),
    portalLogout: publicProcedure.mutation(({ ctx }) => {
      clearPortalSession(ctx.res);
      return { success: true } as const;
    }),
  }),

  news: router({
    latest: publicProcedure.input(z.object({ limit: z.number().min(1).max(30).default(12) }).optional()).query(async ({ input }) => {
      const result = await db.listPublishedArticles(input?.limit ?? 12);
      return result.length > 0 || await db.getDb() ? result : fallbackArticles.slice(0, input?.limit ?? 12);
    }),
    bySlug: publicProcedure.input(z.object({ slug: z.string().min(1) })).query(async ({ input }) => {
      const result = await db.getArticleBySlug(input.slug);
      return result ?? (await db.getDb() ? null : fallbackArticles.find(article => article.slug === input.slug) ?? null);
    }),
    categories: publicProcedure.query(async () => {
      const result = await db.listPublishedArticles(100);
      const items = result.length > 0 || await db.getDb() ? result : fallbackArticles;
      return Array.from(new Set(items.map(article => article.category))).map(name => ({ name, count: items.filter(article => article.category === name).length }));
    }),
    byCategory: publicProcedure.input(z.object({ category: categoryInput })).query(async ({ input }) => {
      const result = await db.listPublishedArticles(100);
      const items = result.length > 0 || await db.getDb() ? result : fallbackArticles;
      return items.filter(article => article.category.toLowerCase() === input.category.toLowerCase());
    }),
  }),

  portal: router({
    stats: portalProcedure.query(async () => {
      const items = await db.listArticlesForAdmin();
      const published = items.filter(article => article.status === "published");
      const media = await db.listMedia(100);
      const hasDatabase = Boolean(await db.getDb());
      const visibleItems = items.length || hasDatabase ? items : fallbackArticles;
      return { totalNews: visibleItems.length, published: hasDatabase ? published.length : (published.length || fallbackArticles.length), media: media.length, categories: new Set(visibleItems.map(article => article.category)).size };
    }),
    listArticles: portalProcedure.query(async () => {
      const result = await db.listArticlesForAdmin();
      return result.length > 0 || await db.getDb() ? result : fallbackArticles;
    }),
    createArticle: portalAdminProcedure.input(articleInput).mutation(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database belum tersedia." });
      const baseSlug = slugify(input.title);
      const slug = `${baseSlug}-${Date.now().toString().slice(-6)}`;
      const created = await database.insert(articles).values({ ...input, slug, videoUrl: input.videoUrl || null, publishedAt: input.status === "published" ? new Date() : null }).$returningId();
      return { id: created[0]?.id, slug };
    }),
    updateArticle: portalAdminProcedure.input(z.object({ id: z.number(), ...articleInput.shape })).mutation(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database belum tersedia." });
      const { id, ...values } = input;
      await database.update(articles).set({ ...values, videoUrl: values.videoUrl || null, publishedAt: values.status === "published" ? new Date() : null }).where(eq(articles.id, id));
      return { success: true };
    }),
    deleteArticle: portalAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database belum tersedia." });
      await database.delete(articles).where(eq(articles.id, input.id));
      return { success: true };
    }),
    media: portalProcedure.query(() => db.listMedia(50)),
    uploadMedia: portalProcedure.input(z.object({ fileName: z.string().min(1).max(255), mimeType: z.string().min(3).max(100), base64: z.string().min(10).max(75_000_000) })).mutation(async ({ ctx, input }) => {
      const kind = input.mimeType.startsWith("video/") ? "video" : input.mimeType.startsWith("image/") ? "photo" : null;
      if (!kind) throw new TRPCError({ code: "BAD_REQUEST", message: "Format media harus berupa foto atau video." });
      const data = Buffer.from(input.base64.replace(/^data:[^;]+;base64,/, ""), "base64");
      const stored = await storagePut(`kilas-touna/${kind}/${input.fileName}`, data, input.mimeType);
      const database = await db.getDb();
      if (!database) return { ...stored, kind };
      const inserted = await database.insert(mediaAssets).values({ storageKey: stored.key, url: stored.url, fileName: input.fileName, mimeType: input.mimeType, kind, uploadedBy: ctx.portalUser.accountId }).$returningId();
      return { ...stored, kind, id: inserted[0]?.id };
    }),
    accounts: portalAdminProcedure.query(() => db.listPortalAccounts()),
    createAccount: portalAdminProcedure.input(z.object({ username: z.string().trim().min(3).max(64), displayName: z.string().trim().min(2).max(120), password: z.string().min(6).max(128), role: z.enum(["user", "admin"]) })).mutation(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database belum tersedia." });
      const username = input.username.toLowerCase();
      const existing = await db.getPortalAccountByUsername(username);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Username tersebut sudah dipakai." });
      await database.insert(portalAccounts).values({ username, displayName: input.displayName, passwordHash: await hashPassword(input.password), role: input.role });
      return { success: true };
    }),
    updateAccount: portalAdminProcedure.input(z.object({ id: z.number(), username: z.string().trim().min(3).max(64), displayName: z.string().trim().min(2).max(120), password: z.string().max(128).optional(), role: z.enum(["user", "admin"]) })).mutation(async ({ input }) => {
      const database = await db.getDb();
      if (!database) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database belum tersedia." });
      const values: Record<string, unknown> = { username: input.username.toLowerCase(), displayName: input.displayName, role: input.role };
      if (input.password) values.passwordHash = await hashPassword(input.password);
      await database.update(portalAccounts).set(values).where(eq(portalAccounts.id, input.id));
      return { success: true };
    }),
  }),

  admin: router({
    me: adminProcedure.query(({ ctx }) => ctx.user),
  }),
});

export type AppRouter = typeof appRouter;
