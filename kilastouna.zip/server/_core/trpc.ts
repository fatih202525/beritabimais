import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin') {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

const requirePortalUser = t.middleware(async opts => {
  const { ctx, next } = opts;
  if (!ctx.portalUser) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Silakan masuk ke portal terlebih dahulu." });
  }
  return next({
    ctx: {
      ...ctx,
      portalUser: ctx.portalUser,
    },
  });
});

export const portalProcedure = t.procedure.use(requirePortalUser);

export const portalAdminProcedure = t.procedure.use(
  requirePortalUser.unstable_pipe(async opts => {
    if (opts.ctx.portalUser?.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Akses admin diperlukan." });
    }
    return opts.next({ ctx: opts.ctx });
  }),
);
