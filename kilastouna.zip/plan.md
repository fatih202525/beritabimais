# Rencana Implementasi Kilas Bimais Touna

## Ruang lingkup
Kilas Bimais Touna adalah portal berita berbahasa Indonesia untuk mengabarkan kegiatan Bimas Islam dan KUA se-Kabupaten Tojo Una-Una. Produk mencakup beranda berita, daftar dan detail artikel, kategori, foto/video, berbagi ke WhatsApp dan Facebook, login berbasis peran, manajemen berita, manajemen akun oleh admin, serta unggah media oleh admin dan user terautentikasi.

## Pendekatan implementasi
- Frontend React + TypeScript + Tailwind pada starter Webdev.
- Backend Express + tRPC + Drizzle dengan database MySQL terkelola.
- Auth portal memakai akun username/password karena itu diminta eksplisit oleh pengguna; cookie sesi aplikasi diberi `SameSite=None; Secure` agar kompatibel dengan Preview iframe. Role `admin` dan `user` dipakai untuk membatasi manajemen akun/berita.
- Storage media memakai object storage Manus melalui endpoint presign di server; indeks media dan relasi artikel disimpan di database.
- Konten demo disediakan melalui data seed/fallback agar tampilan bermakna sebelum redaksi memasukkan berita pertama.
- Route publik: `/`, `/berita`, `/berita/:slug`, `/kategori/:slug`, `/login`. Route privat: `/dashboard`, `/dashboard/berita`, `/dashboard/media`, `/dashboard/pengguna`.

## Struktur proyek
- `client/src/App.tsx`: route manifest sisi klien dan shell aplikasi.
- `client/src/pages/`: beranda, daftar/detail berita, login, dashboard.
- `client/src/components/`: header portal, kartu berita, tombol share, komponen media.
- `client/src/index.css`: token warna, tipografi, layout editorial, responsif.
- `server/routers.ts`: prosedur tRPC untuk berita, auth portal, akun, media dan statistik.
- `server/db.ts`: query terisolasi untuk domain berita.
- `server/storage.ts`: helper presign object storage.
- `drizzle/schema.ts` dan `drizzle/*.sql`: model users, portal accounts, articles, media.
- `public/manus-routes.json`: daftar route publik/private yang dikontrol aplikasi.

## Desain

### Alternatif gaya
- **Kemenag editorial modern** (0.06): portal pemerintahan yang rapi dengan pita hijau, blok berita putih, dan aksen emas.
- **Ruang redaksi pesisir** (0.04): editorial hangat dengan biru laut dan kartu foto besar.
- **Minimal birokrasi digital** (0.08): sangat bersih, monokrom, dengan satu warna aksen.

Pilihan: **Kemenag editorial modern**, karena paling setia pada permintaan pengguna untuk mengikuti bahasa visual situs kemenag.go.id sambil tetap memberi identitas lokal.

### Prinsip inti
1. Informasi utama terlihat dalam satu sapuan: berita utama, berita terbaru, kategori, dan agenda.
2. Rasa resmi dibangun lewat struktur, jarak dan tipografi, bukan ornamen berlebihan.
3. Media foto/video menjadi pintu masuk berita kegiatan, bukan dekorasi.
4. Akses admin/user tetap terasa bagian dari portal, bukan aplikasi yang terpisah.

### Filosofi warna
Hijau tua menjadi warna kepemilikan yang mengingatkan pada identitas Kemenag dan kepercayaan publik. Emas dipakai sebagai penanda aksen dan momen penting. Latar krem terang membuat halaman terasa hangat seperti buletin resmi, sementara biru laut kecil menjadi aksen lokal Tojo Una-Una.

### Paradigma layout
Pita identitas horizontal di bagian atas, header editorial dua tingkat, lalu layout asimetris: kolom utama untuk berita unggulan dan feed terbaru, rail kanan untuk kategori, statistik dan video. Pada mobile, rail turun setelah feed dan navigasi menjadi scroll horizontal.

### Elemen khas
- Garis emas tipis di bawah header dan label rubrik berbentuk kapsul.
- Kartu berita utama dengan media 16:9 dan overlay label kategori.
- Motif sudut pentagonal sederhana yang merujuk bentuk logo Kemenag tanpa menggambar ulang logonya.

### Interaksi dan animasi
Hover hanya menaikkan kartu 2–4px dan memperkuat garis aksen. Tombol share membuka menu ringan. Filter kategori memperbarui daftar tanpa mengubah konteks halaman. Animasi masuk memakai fade/slide pendek dan menghormati `prefers-reduced-motion`.

### Tipografi
Gunakan `Georgia` untuk headline editorial agar terasa seperti surat kabar resmi, dipasangkan dengan `Arial`/system sans untuk navigasi dan metadata. H1 tebal dan rapat, subhead 16–18px, metadata 12–13px dengan tracking kecil.

### Brand essence
Portal kegiatan Bimas Islam dan KUA Tojo Una-Una yang ringkas, terpercaya, dan dekat dengan warga. Kepribadian: resmi, hangat, tangkas.

### Brand voice
Judul dan CTA harus informatif, langsung, dan tidak bombastis. Contoh: “KUA Ampana Kota Perkuat Layanan Konsultasi Keluarga” dan “Lihat seluruh kabar dari Bimas Islam Touna”.

### Wordmark & logo
Wordmark “KILAS / BIMAIS TOUNA” memakai susunan dua baris dengan aksen garis emas. Logo resmi Kementerian Agama ditempatkan sebagai emblem pendamping di sisi kiri, dengan ukuran dan jarak yang tidak mengubah bentuk aslinya.

### Signature brand color
`#0B6B4B` — hijau Kilas Touna, warna hijau tua yang terasa resmi namun lebih segar daripada hijau generik.
