import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import { useEffect } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import NewsList from "./pages/NewsList";
import NewsDetail from "./pages/NewsDetail";
import Login from "./pages/Login";
import DashboardRouter from "./pages/Dashboard";

function PageMeta() {
  const [location] = useLocation();
  useEffect(() => {
    const titles: Record<string, string> = {
      "/": "Kilas Bimais Touna — Berita Bimas Islam & KUA",
      "/berita": "Berita — Kilas Bimais Touna",
      "/login": "Login Ruang Redaksi — Kilas Bimais Touna",
      "/dashboard": "Dashboard — Kilas Bimais Touna",
    };
    document.title = titles[location] ?? (location.startsWith("/dashboard") ? "Ruang Redaksi — Kilas Bimais Touna" : "Kilas Bimais Touna");
    const description = document.querySelector('meta[name="description"]');
    description?.setAttribute("content", "Kilas Bimais Touna mengabarkan kegiatan Bimas Islam dan KUA se-Kabupaten Tojo Una-Una secara ringkas, resmi, dan dekat dengan masyarakat.");
  }, [location]);
  return null;
}

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/berita" component={NewsList} />
    <Route path="/berita/:slug" component={NewsDetail} />
    <Route path="/kategori/:slug" component={NewsList} />
    <Route path="/login" component={Login} />
    <Route path="/dashboard/berita" component={DashboardRouter} />
    <Route path="/dashboard/media" component={DashboardRouter} />
    <Route path="/dashboard/pengguna" component={DashboardRouter} />
    <Route path="/dashboard" component={DashboardRouter} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><PageMeta /><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
