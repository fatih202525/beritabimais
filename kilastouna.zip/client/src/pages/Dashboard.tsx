import { BarChart3, FilePlus2, FolderOpen, ImagePlus, LayoutDashboard, Loader2, LogOut, Menu, Shield, Trash2, UploadCloud, Users, Video, X } from "lucide-react";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { formatDate } from "@/components/NewsCard";

type ArticleForm = { title: string; excerpt: string; content: string; category: string; imageUrl: string; videoUrl: string; authorName: string; status: "draft" | "published" };
const emptyArticle: ArticleForm = { title: "", excerpt: "", content: "", category: "Bimas Islam", imageUrl: "", videoUrl: "", authorName: "Redaksi Kilas Touna", status: "published" };

function DashboardShell({ children, title }: { children: ReactNode; title: string }) {
  const [, setLocation] = useLocation();
  const me = trpc.auth.portalMe.useQuery();
  const logout = trpc.auth.portalLogout.useMutation({ onSuccess: () => setLocation("/login") });
  const [collapsed, setCollapsed] = useState(false);
  useEffect(() => { if (!me.isLoading && !me.data) setLocation("/login"); }, [me.data, me.isLoading, setLocation]);
  if (me.isLoading || !me.data) return <div className="dashboard-loading"><Loader2 className="spin" /> Memeriksa sesi...</div>;
  const isAdmin = me.data.role === "admin";
  const links = [{ href: "/dashboard", label: "Ringkasan", icon: LayoutDashboard }, { href: "/dashboard/berita", label: "Kelola berita", icon: FilePlus2 }, { href: "/dashboard/media", label: "Media", icon: FolderOpen }, ...(isAdmin ? [{ href: "/dashboard/pengguna", label: "Pengguna", icon: Users }] : [])];
  return <div className={`dashboard-shell ${collapsed ? "sidebar-collapsed" : ""}`}><aside className="dashboard-sidebar"><div className="dash-brand"><img src="/kemenag-logo.png" alt="" /><span><strong>KILAS</strong><small>RUANG REDAKSI</small></span></div><div className="dash-user"><span className="user-avatar">{me.data.displayName.slice(0, 1)}</span><div><strong>{me.data.displayName}</strong><small>{isAdmin ? "Administrator" : "Kontributor"}</small></div></div><nav className="dash-nav">{links.map(item => <Link key={item.href} href={item.href} className="dash-nav-link"><item.icon size={18} /><span>{item.label}</span></Link>)}</nav><div className="dash-sidebar-bottom"><Link href="/" className="dash-back">Lihat portal publik</Link><button className="dash-logout" onClick={() => logout.mutate()}><LogOut size={16} /><span>Keluar</span></button></div></aside><section className="dashboard-main"><header className="dashboard-topbar"><button className="dash-menu" onClick={() => setCollapsed(value => !value)}><Menu size={19} /></button><div><span className="eyebrow">RUANG REDAKSI</span><h1>{title}</h1></div><span className="dash-role"><Shield size={14} /> {isAdmin ? "Admin" : "User"}</span></header>{children}</section></div>;
}

export function DashboardHome() {
  const stats = trpc.portal.stats.useQuery();
  const articles = trpc.portal.listArticles.useQuery();
  return <DashboardShell title="Ringkasan"><div className="dashboard-content"><div className="stats-grid"><div className="stat-card"><span>Total berita</span><strong>{stats.data?.totalNews ?? "—"}</strong><small><BarChart3 size={13} /> Koleksi redaksi</small></div><div className="stat-card stat-green"><span>Terbit</span><strong>{stats.data?.published ?? "—"}</strong><small><Shield size={13} /> Siap dibaca publik</small></div><div className="stat-card stat-gold"><span>Media</span><strong>{stats.data?.media ?? "—"}</strong><small><ImagePlus size={13} /> Foto &amp; video</small></div><div className="stat-card stat-blue"><span>Rubrik aktif</span><strong>{stats.data?.categories ?? "—"}</strong><small><FolderOpen size={13} /> Kategori berita</small></div></div><div className="dash-columns"><div className="dash-panel"><div className="panel-heading"><div><span className="eyebrow">Konten terbaru</span><h2>Berita di ruang redaksi</h2></div><Link href="/dashboard/berita" className="panel-action">Kelola <span>→</span></Link></div><div className="mini-list">{(articles.data ?? []).slice(0, 5).map(article => <Link href={`/berita/${article.slug}`} key={article.slug} className="mini-list-row"><img src={article.imageUrl} alt="" /><div><strong>{article.title}</strong><span>{article.category} · {formatDate(article.publishedAt)}</span></div><span className={`status-dot ${article.status}`}>{article.status === "published" ? "Terbit" : "Draft"}</span></Link>)}</div></div><div className="dash-panel dash-welcome"><span className="welcome-mark"><Video size={24} /></span><span className="eyebrow">Kilas untuk publik</span><h2>Jaga kabar tetap hidup.</h2><p>Gunakan ruang redaksi untuk mengarsipkan dokumentasi kegiatan, menulis berita, dan membagikannya ke masyarakat.</p><Link href="/dashboard/media" className="secondary-button">Unggah media <UploadCloud size={15} /></Link></div></div></div></DashboardShell>;
}

export function ManageNews() {
  const articles = trpc.portal.listArticles.useQuery();
  const [editing, setEditing] = useState<number | null>(null);
  const [form, setForm] = useState(emptyArticle);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const uploadPhoto = trpc.portal.uploadMedia.useMutation({ onSuccess: data => setForm(value => ({ ...value, imageUrl: data.url })) });
  const handlePhoto = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    if (file.size > 25 * 1024 * 1024) return;
    const reader = new FileReader();
    reader.onload = () => uploadPhoto.mutate({ fileName: file.name, mimeType: file.type, base64: String(reader.result) });
    reader.readAsDataURL(file);
  };
  const create = trpc.portal.createArticle.useMutation({ onSuccess: () => { articles.refetch(); setForm(emptyArticle); setEditing(null); } });
  const update = trpc.portal.updateArticle.useMutation({ onSuccess: () => { articles.refetch(); setForm(emptyArticle); setEditing(null); } });
  const remove = trpc.portal.deleteArticle.useMutation({ onSuccess: () => articles.refetch() });
  const submit = (event: FormEvent) => { event.preventDefault(); if (editing) update.mutate({ id: editing, ...form }); else create.mutate(form); };
  const startEdit = (article: any) => { setEditing(article.id); setForm({ title: article.title, excerpt: article.excerpt, content: article.content, category: article.category, imageUrl: article.imageUrl, videoUrl: article.videoUrl ?? "", authorName: article.authorName, status: article.status }); window.scrollTo({ top: 0, behavior: "smooth" }); };
  return <DashboardShell title="Kelola berita"><div className="dashboard-content news-admin"><div className="dash-panel editor-panel"><div className="panel-heading"><div><span className="eyebrow">{editing ? "Edit naskah" : "Naskah baru"}</span><h2>{editing ? "Perbarui berita" : "Tulis berita"}</h2></div>{editing && <button className="ghost-button" onClick={() => { setEditing(null); setForm(emptyArticle); }}><X size={15} /> Batal edit</button>}</div><form className="article-form" onSubmit={submit}><div className="form-two"><label>Judul berita<input required value={form.title} onChange={event => setForm({ ...form, title: event.target.value })} placeholder="Tulis judul berita yang jelas" /></label><label>Rubrik<select value={form.category} onChange={event => setForm({ ...form, category: event.target.value })}><option>Bimas Islam</option><option>KUA</option><option>Penyuluh</option><option>Moderasi Beragama</option></select></label></div><label>Ringkasan<textarea required rows={2} value={form.excerpt} onChange={event => setForm({ ...form, excerpt: event.target.value })} placeholder="Satu atau dua kalimat untuk kartu berita" /></label><label>Isi berita<textarea required rows={6} value={form.content} onChange={event => setForm({ ...form, content: event.target.value })} placeholder="Tulis isi berita di sini..." /></label><div className="form-two"><label>Foto utama<input ref={photoInputRef} required={!form.imageUrl} type="file" accept="image/*" onChange={event => handlePhoto(event.target.files?.[0])} />{uploadPhoto.isPending && <small className="upload-message">Mengunggah foto...</small>}{form.imageUrl && <img src={form.imageUrl} alt="Preview foto berita" style={{ width: "100%", maxHeight: 180, objectFit: "cover", marginTop: 8 }} />}</label><label>URL video (opsional)<input type="url" value={form.videoUrl} onChange={event => setForm({ ...form, videoUrl: event.target.value })} placeholder="https://..." /></label></div><div className="form-two"><label>Penulis<input required value={form.authorName} onChange={event => setForm({ ...form, authorName: event.target.value })} /></label><label>Status<select value={form.status} onChange={event => setForm({ ...form, status: event.target.value as "draft" | "published" })}><option value="published">Terbitkan</option><option value="draft">Simpan sebagai draft</option></select></label></div><div className="form-actions"><button className="primary-button" disabled={create.isPending || update.isPending}>{editing ? "Simpan perubahan" : "Terbitkan berita"} <FilePlus2 size={15} /></button>{(create.error || update.error) && <span className="form-error">{(create.error || update.error)?.message}</span>}</div></form></div><div className="dash-panel"><div className="panel-heading"><div><span className="eyebrow">Arsip naskah</span><h2>Berita tersimpan</h2></div><span className="count-label">{articles.data?.length ?? 0} naskah</span></div><div className="admin-article-list">{(articles.data ?? []).map(article => <div className="admin-article-row" key={article.id}><img src={article.imageUrl} alt="" /><div><strong>{article.title}</strong><span>{article.category} · {formatDate(article.publishedAt)}</span></div><span className={`status-dot ${article.status}`}>{article.status === "published" ? "Terbit" : "Draft"}</span><div className="row-actions"><button onClick={() => startEdit(article)}>Edit</button><button onClick={() => remove.mutate({ id: article.id })}><Trash2 size={14} /></button></div></div>)}</div></div></div></DashboardShell>;
}

export function ManageMedia() {
  const media = trpc.portal.media.useQuery();
  const upload = trpc.portal.uploadMedia.useMutation({ onSuccess: () => media.refetch() });
  const inputRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");
  const handleFiles = async (files: FileList | null) => { const file = files?.[0]; if (!file) return; if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) { setMessage("Pilih file foto atau video."); return; } if (file.size > 25 * 1024 * 1024) { setMessage("Ukuran maksimal 25 MB untuk unggahan demo ini."); return; } const reader = new FileReader(); reader.onload = () => { const base64 = String(reader.result); upload.mutate({ fileName: file.name, mimeType: file.type, base64 }, { onSuccess: () => setMessage("Media berhasil diunggah ke penyimpanan proyek."), onError: error => setMessage(error.message) }); }; reader.readAsDataURL(file); };
  return <DashboardShell title="Media"><div className="dashboard-content"><div className="media-upload-panel" onClick={() => inputRef.current?.click()}><input ref={inputRef} type="file" accept="image/*,video/*" hidden onChange={event => handleFiles(event.target.files)} /><div className="upload-icon"><UploadCloud size={28} /></div><h2>{upload.isPending ? "Mengunggah..." : "Unggah foto atau video"}</h2><p>Tarik file ke sini atau klik untuk memilih. Format foto dan video, maksimal 25 MB.</p><button className="secondary-button" type="button">Pilih file</button>{message && <span className="upload-message">{message}</span>}</div><div className="dash-panel"><div className="panel-heading"><div><span className="eyebrow">Pustaka media</span><h2>Unggahan terbaru</h2></div></div><div className="media-grid">{(media.data ?? []).map(item => <div className="media-item" key={item.id}><img src={item.url} alt={item.fileName} /><span>{item.kind === "video" ? <Video size={13} /> : <ImagePlus size={13} />} {item.fileName}</span></div>)}</div>{(media.data ?? []).length === 0 && <div className="empty-state compact"><p>Belum ada unggahan. Foto dan video yang Anda pilih akan tersimpan di sini.</p></div>}</div></div></DashboardShell>;
}

export function ManageUsers() {
  const accounts = trpc.portal.accounts.useQuery();
  const create = trpc.portal.createAccount.useMutation({ onSuccess: () => { accounts.refetch(); setForm({ username: "", displayName: "", password: "", role: "user" }); } });
  const update = trpc.portal.updateAccount.useMutation({ onSuccess: () => { accounts.refetch(); setEditing(null); setForm({ username: "", displayName: "", password: "", role: "user" }); } });
  const [editing, setEditing] = useState<number | null>(null);
  const [form, setForm] = useState({ username: "", displayName: "", password: "", role: "user" as "user" | "admin" });
  const submit = (event: FormEvent) => { event.preventDefault(); if (editing) update.mutate({ id: editing, ...form }); else create.mutate(form); };
  return <DashboardShell title="Pengguna"><div className="dashboard-content users-admin"><div className="dash-panel editor-panel"><div className="panel-heading"><div><span className="eyebrow">Akun portal</span><h2>{editing ? "Edit akun" : "Tambah akun"}</h2></div></div><form className="article-form" onSubmit={submit}><label>Username<input required value={form.username} onChange={event => setForm({ ...form, username: event.target.value })} placeholder="contoh: kua_ampana" /></label><label>Nama tampilan<input required value={form.displayName} onChange={event => setForm({ ...form, displayName: event.target.value })} placeholder="Nama pengguna" /></label><label>Password<input required={!editing} type="password" value={form.password} onChange={event => setForm({ ...form, password: event.target.value })} placeholder={editing ? "Kosongkan jika tidak diubah" : "Minimal 6 karakter"} /></label><label>Peran<select value={form.role} onChange={event => setForm({ ...form, role: event.target.value as "user" | "admin" })}><option value="user">User / Kontributor</option><option value="admin">Admin</option></select></label><div className="form-actions"><button className="primary-button">{editing ? "Simpan akun" : "Tambah akun"} <Users size={15} /></button></div></form></div><div className="dash-panel"><div className="panel-heading"><div><span className="eyebrow">Akun terdaftar</span><h2>Tim Kilas Touna</h2></div></div><div className="user-list">{(accounts.data ?? []).map(account => <div className="user-row" key={account.id}><span className="user-avatar">{account.displayName.slice(0, 1)}</span><div><strong>{account.displayName}</strong><span>@{account.username}</span></div><span className={`role-tag ${account.role}`}>{account.role === "admin" ? "Admin" : "User"}</span><button onClick={() => { setEditing(account.id); setForm({ username: account.username, displayName: account.displayName, password: "", role: account.role }); }}>Edit</button></div>)}</div></div></div></DashboardShell>;
}

export default function DashboardRouter() {
  const [isNews] = useRoute("/dashboard/berita");
  const [isMedia] = useRoute("/dashboard/media");
  const [isUsers] = useRoute("/dashboard/pengguna");
  if (isNews) return <ManageNews />;
  if (isMedia) return <ManageMedia />;
  if (isUsers) return <ManageUsers />;
  return <DashboardHome />;
}
