import { Filter, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { PortalLayout } from "@/components/PortalHeader";
import { NewsCard, SectionHeading } from "@/components/NewsCard";
import { trpc } from "@/lib/trpc";

export default function NewsList() {
  const [, params] = useRoute("/kategori/:slug");
  const category = params?.slug ? decodeURIComponent(params.slug).replace(/-/g, " ") : "";
  const allNews = trpc.news.latest.useQuery({ limit: 30 });
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => (allNews.data ?? []).filter(article => {
    const matchesCategory = !category || article.category.toLowerCase() === category.toLowerCase();
    const needle = search.trim().toLowerCase();
    return matchesCategory && (!needle || `${article.title} ${article.excerpt}`.toLowerCase().includes(needle));
  }), [allNews.data, category, search]);
  const title = category ? `Berita ${category.replace(/\b\w/g, letter => letter.toUpperCase())}` : "Semua berita";

  return <PortalLayout><main className="site-container listing-page"><div className="listing-intro"><div><span className="eyebrow">KILAS BIMAIS TOUNA</span><h1>{title}</h1><p>Catatan kegiatan, layanan, dan cerita dari Bimas Islam serta Kantor Urusan Agama se-Kabupaten Tojo Una-Una.</p></div><div className="listing-tools"><label><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Cari berita..." /></label><Link href="/berita" className="filter-button"><Filter size={15} /> Semua rubrik</Link></div></div><div className="listing-rule"><span>{filtered.length} berita ditampilkan</span><span>Terbaru ke terlama</span></div><div className="listing-grid">{filtered.map(article => <NewsCard key={article.slug} article={article} />)}</div>{filtered.length === 0 && <div className="empty-state"><h2>Berita belum ditemukan</h2><p>Coba gunakan kata kunci lain atau pilih rubrik yang berbeda.</p></div>}</main></PortalLayout>;
}

export function CategoryPage() { return <NewsList />; }
