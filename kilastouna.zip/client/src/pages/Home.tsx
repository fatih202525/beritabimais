import { ArrowRight, CalendarDays, ChevronRight, Play, Radio, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { PortalLayout } from "@/components/PortalHeader";
import { NewsCard, SectionHeading, formatDate } from "@/components/NewsCard";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const news = trpc.news.latest.useQuery({ limit: 6 });
  const categories = trpc.news.categories.useQuery();
  const articles = news.data ?? [];
  const featured = articles[0];
  const secondary = articles.slice(1, 3);

  return <PortalLayout>
    <main>
      <div className="announcement"><div className="site-container announcement-inner"><span className="announcement-label"><Radio size={14} /> Kabar Terkini</span><span>Selamat datang di portal informasi Bimas Islam dan KUA se-Kabupaten Tojo Una-Una.</span><Link href="/berita">Lihat seluruh berita <ArrowRight size={14} /></Link></div></div>
      <section className="site-container hero-section">
        <div className="hero-copy"><span className="eyebrow">KILAS UTAMA · {featured?.category ?? "Bimas Islam"}</span><h1>{featured?.title ?? "Mengabarkan kerja nyata Bimas Islam dari Tojo Una-Una"}</h1><p>{featured?.excerpt ?? "Informasi terpercaya tentang layanan keagamaan, kegiatan penyuluh, dan kabar Kantor Urusan Agama di seluruh wilayah Tojo Una-Una."}</p><div className="hero-meta"><span><CalendarDays size={14} /> {formatDate(featured?.publishedAt)}</span><span>Oleh {featured?.authorName ?? "Redaksi Kilas Touna"}</span></div><Link href={featured ? `/berita/${featured.slug}` : "/berita"} className="primary-button">Baca berita utama <ArrowRight size={16} /></Link></div>
        <div className="hero-media">{featured && <><img src={featured.imageUrl} alt="" /><div className="hero-caption"><span>Berita pilihan redaksi</span><strong>Menjaga layanan tetap dekat dengan masyarakat</strong></div></>}</div>
      </section>
      <section className="site-container quick-links"><div><ShieldCheck size={20} /><div><strong>Resmi &amp; Terverifikasi</strong><span>Informasi dari unit kerja Kemenag Touna</span></div></div><div><Radio size={20} /><div><strong>Update Kegiatan</strong><span>Kabar terbaru dari lapangan</span></div></div><div><Play size={20} /><div><strong>Foto &amp; Video</strong><span>Dokumentasi kegiatan Bimas Islam</span></div></div></section>
      <section className="site-container content-section"><SectionHeading eyebrow="Dari lapangan" title="Berita terbaru" action={<Link href="/berita" className="text-link">Semua berita <ChevronRight size={16} /></Link>} /><div className="news-grid">{articles.slice(1, 5).map(article => <NewsCard key={article.slug} article={article} />)}</div></section>
      <section className="site-container split-section"><div className="category-panel"><SectionHeading eyebrow="Jelajahi rubrik" title="Kabar sesuai kebutuhan" /><div className="category-list">{(categories.data ?? [{ name: "Bimas Islam", count: 3 }, { name: "KUA", count: 2 }, { name: "Penyuluh", count: 1 }]).map(category => <Link key={category.name} href={`/kategori/${category.name.toLowerCase().replace(/\s+/g, "-")}`} className="category-row"><span>{category.name}</span><span>{category.count.toString().padStart(2, "0")} <ChevronRight size={15} /></span></Link>)}</div></div><div className="video-panel"><div className="video-panel-top"><div><span className="eyebrow">Kilas visual</span><h2>Dokumentasi kegiatan</h2></div><span className="video-mark"><Play size={14} fill="currentColor" /></span></div><div className="video-cover"><img src={articles.find(article => article.videoUrl)?.imageUrl ?? featured?.imageUrl} alt="Dokumentasi kegiatan" /><div className="play-circle"><Play size={24} fill="currentColor" /></div><span>Video Bimas Islam</span></div></div></section>
      <section className="site-container cta-band"><div><span className="eyebrow">Ruang redaksi</span><h2>Punya kabar kegiatan untuk dibagikan?</h2><p>Admin dan kontributor terdaftar dapat mengunggah foto, video, serta mengirim naskah berita melalui ruang redaksi.</p></div><Link href="/login" className="secondary-button">Masuk ke ruang redaksi <ArrowRight size={16} /></Link></section>
    </main>
  </PortalLayout>;
}
