import { ArrowLeft, CalendarDays, Clock3, MapPin } from "lucide-react";
import { Link, useRoute } from "wouter";
import { PortalLayout } from "@/components/PortalHeader";
import { NewsCard, formatDate } from "@/components/NewsCard";
import { ShareButtons } from "@/components/ShareButtons";
import { trpc } from "@/lib/trpc";

export default function NewsDetail() {
  const [, params] = useRoute("/berita/:slug");
  const article = trpc.news.bySlug.useQuery({ slug: params?.slug ?? "" });
  const latest = trpc.news.latest.useQuery({ limit: 5 });
  if (article.isLoading) return <PortalLayout><div className="page-loading">Memuat berita...</div></PortalLayout>;
  if (!article.data) return <PortalLayout><div className="empty-state article-not-found"><h1>Berita tidak ditemukan</h1><p>Artikel yang Anda cari mungkin sudah dipindahkan atau belum diterbitkan.</p><Link href="/berita" className="primary-button">Kembali ke berita</Link></div></PortalLayout>;
  const item = article.data;
  return <PortalLayout><main className="article-page site-container"><div className="article-breadcrumb"><Link href="/berita"><ArrowLeft size={15} /> Semua berita</Link><span>•</span><span>{item.category}</span></div><div className="article-layout"><article><span className="eyebrow">{item.category}</span><h1>{item.title}</h1><p className="article-dek">{item.excerpt}</p><div className="article-byline"><span className="byline-avatar">{item.authorName.slice(0, 1)}</span><div><strong>{item.authorName}</strong><span><CalendarDays size={13} /> {formatDate(item.publishedAt)} <i>·</i> <Clock3 size={13} /> 4 menit baca</span></div></div><img src={item.imageUrl} alt="" className="article-hero" />{item.videoUrl && <div className="article-video-note">Video pendukung tersedia melalui dokumentasi kegiatan.</div>}<div className="article-content"><p>{item.content}</p><p>Melalui kolaborasi yang konsisten, layanan keagamaan di Tojo Una-Una terus diarahkan agar mudah dijangkau, informatif, dan memberi dampak langsung bagi masyarakat. Kilas Bimais Touna akan terus mengikuti kabar dari lapangan.</p></div><div className="article-location"><MapPin size={17} /><span><strong>Tojo Una-Una</strong><small>Sulawesi Tengah, Indonesia</small></span></div><ShareButtons title={item.title} /></article><aside className="article-aside"><div className="aside-card"><span className="eyebrow">Kabar lainnya</span><h3>Berita terbaru</h3>{(latest.data ?? []).filter(news => news.slug !== item.slug).slice(0, 3).map(news => <NewsCard key={news.slug} article={news} />)}</div></aside></div></main></PortalLayout>;
}
