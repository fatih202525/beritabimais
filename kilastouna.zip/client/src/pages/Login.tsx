import { ArrowRight, LockKeyhole, UserRound } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { PortalLayout } from "@/components/PortalHeader";
import { trpc } from "@/lib/trpc";

export default function Login() {
  const [, setLocation] = useLocation();
  const me = trpc.auth.portalMe.useQuery();
  const login = trpc.auth.portalLogin.useMutation({ onSuccess: () => { me.refetch(); setLocation("/dashboard"); } });
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  useEffect(() => { if (me.data) setLocation("/dashboard"); }, [me.data, setLocation]);
  const submit = (event: FormEvent) => { event.preventDefault(); login.mutate({ username, password }); };
  return <PortalLayout><main className="login-page"><div className="login-art"><div className="login-art-inner"><span className="eyebrow">RUANG REDAKSI</span><h1>Setiap kegiatan punya cerita yang layak diketahui.</h1><p>Masuk untuk mengelola berita, mengunggah dokumentasi, dan menjaga kabar Bimas Islam tetap dekat dengan masyarakat.</p><div className="login-art-sign"><img src="/kemenag-logo.png" alt="Logo Kementerian Agama" /><span>Kilas Bimais Touna<br /><small>Tojo Una-Una</small></span></div></div></div><div className="login-panel"><div className="login-card"><span className="eyebrow">AKSES PORTAL</span><h2>Masuk ke ruang redaksi</h2><p className="login-intro">Gunakan username dan password akun yang diberikan admin.</p><form onSubmit={submit}><label>Username<div className="input-with-icon"><UserRound size={17} /><input value={username} onChange={event => setUsername(event.target.value)} autoComplete="username" required /></div></label><label>Password<div className="input-with-icon"><LockKeyhole size={17} /><input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete="current-password" required /></div></label>{login.error && <div className="form-error">{login.error.message}</div>}<button className="primary-button login-submit" disabled={login.isPending}>{login.isPending ? "Memeriksa..." : "Masuk sekarang"} <ArrowRight size={16} /></button></form><Link href="/" className="back-home">Kembali ke portal publik</Link></div></div></main></PortalLayout>;
}
