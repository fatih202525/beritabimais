import { trpc } from "@/lib/trpc";
import { Bell, ChevronDown, LogIn, LogOut, Menu, Search, X } from "lucide-react";
import { useState } from "react";
import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";

const navItems = [
  { label: "Beranda", href: "/" },
  { label: "Berita", href: "/berita" },
  { label: "Bimas Islam", href: "/kategori/bimas-islam" },
  { label: "KUA", href: "/kategori/kua" },
  { label: "Penyuluh", href: "/kategori/penyuluh" },
];

export function PortalHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const portalMe = trpc.auth.portalMe.useQuery();
  const logout = trpc.auth.portalLogout.useMutation({ onSuccess: () => portalMe.refetch() });

  return (
    <>
      <div className="top-strip">
        <div className="site-container top-strip-inner">
          <span>Portal berita kegiatan Bimas Islam dan KUA</span>
          <span className="top-strip-right"><Bell size={13} /> Tojo Una-Una, Sulawesi Tengah</span>
        </div>
      </div>
      <header className="site-header">
        <div className="site-container header-main">
          <Link href="/" className="brand-lockup" aria-label="Kilas Bimais Touna beranda">
            <img src="/kemenag-logo.png" alt="Logo Kementerian Agama Republik Indonesia" className="kemenag-logo" />
            <span className="brand-divider" />
            <span className="brand-wordmark"><strong>KILAS</strong><em>BIMAIS TOUNA</em><small>Berita Bimas Islam &amp; KUA</small></span>
          </Link>
          <div className="header-actions">
            <button className="icon-button" aria-label="Cari"><Search size={18} /></button>
            {portalMe.data ? (
              <div className="user-menu-wrap">
                <Link href="/dashboard" className="user-pill"><span className="user-avatar">{portalMe.data.displayName.slice(0, 1).toUpperCase()}</span><span>{portalMe.data.displayName}</span><ChevronDown size={14} /></Link>
                <button className="logout-link" onClick={() => logout.mutate()}><LogOut size={14} /> Keluar</button>
              </div>
            ) : (
              <Link href="/login" className="login-button"><LogIn size={16} /> Masuk</Link>
            )}
            <button className="mobile-menu-button" aria-label={open ? "Tutup menu" : "Buka menu"} onClick={() => setOpen(value => !value)}>{open ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
        <nav className={`main-nav ${open ? "is-open" : ""}`}>
          <div className="site-container nav-inner">
            {navItems.map(item => <Link key={item.href} href={item.href} className={`nav-link ${location === item.href ? "active" : ""}`} onClick={() => setOpen(false)}>{item.label}</Link>)}
            <Link href="/dashboard" className="nav-link nav-admin" onClick={() => setOpen(false)}>Ruang Redaksi</Link>
          </div>
        </nav>
      </header>
    </>
  );
}

export function PageFooter() {
  return <footer className="site-footer"><div className="site-container footer-grid"><div><div className="footer-brand">KILAS <span>BIMAIS TOUNA</span></div><p>Media informasi kegiatan Bimas Islam dan Kantor Urusan Agama se-Kabupaten Tojo Una-Una.</p></div><div><span className="footer-label">Rubrik</span><Link href="/kategori/bimas-islam">Bimas Islam</Link><Link href="/kategori/kua">KUA</Link><Link href="/kategori/penyuluh">Penyuluh</Link></div><div><span className="footer-label">Kontak</span><span>Jl. Masjid Raya, Ampana</span><span>Kabupaten Tojo Una-Una</span><span>Sulawesi Tengah</span></div></div><div className="site-container footer-bottom"><span>© 2026 Kilas Bimais Touna</span><span>Bagian Humas &amp; Informasi</span></div></footer>;
}

export function PortalLayout({ children }: { children: ReactNode }) {
  return <div className="app-shell"><PortalHeader />{children}<PageFooter /></div>;
}
