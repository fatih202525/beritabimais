import { ArrowUpRight, CalendarDays, Play } from "lucide-react";
import { Link } from "wouter";
import type { ReactNode } from "react";

type NewsLike = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  imageUrl: string;
  videoUrl?: string | null;
  authorName: string;
  publishedAt?: Date | string | null;
};

export function formatDate(value?: Date | string | null) {
  if (!value) return "Baru saja";
  return new Intl.DateTimeFormat("id-ID", { day: "2-digit", month: "long", year: "numeric" }).format(new Date(value));
}

export function NewsCard({ article, featured = false }: { article: NewsLike; featured?: boolean }) {
  return <Link href={`/berita/${article.slug}`} className={`news-card ${featured ? "news-card-featured" : ""}`}>
    <div className="news-image-wrap"><img src={article.imageUrl} alt="" className="news-image" />{article.videoUrl && <span className="video-badge"><Play size={12} fill="currentColor" /> Video</span>}<span className="category-badge">{article.category}</span></div>
    <div className="news-card-body"><div className="news-meta"><CalendarDays size={13} /> {formatDate(article.publishedAt)} <span>•</span> {article.authorName}</div><h3>{article.title}</h3><p>{article.excerpt}</p><span className="read-more">Baca selengkapnya <ArrowUpRight size={15} /></span></div>
  </Link>;
}

export function SectionHeading({ eyebrow, title, action }: { eyebrow: string; title: string; action?: ReactNode }) {
  return <div className="section-heading"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>{action}</div>;
}
