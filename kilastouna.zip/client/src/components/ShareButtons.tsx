import { Check, Copy, Facebook, MessageCircle, Share2 } from "lucide-react";
import { useState } from "react";

export function ShareButtons({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);
  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const encodedUrl = encodeURIComponent(shareUrl);
  const encodedTitle = encodeURIComponent(title);
  const copyLink = async () => {
    try { await navigator.clipboard.writeText(shareUrl); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } catch { /* clipboard may be unavailable in an embedded preview */ }
  };
  return <div className="share-row"><span><Share2 size={15} /> Bagikan</span><a className="share-button share-wa" href={`https://wa.me/?text=${encodedTitle}%20${encodedUrl}`} target="_blank" rel="noreferrer"><MessageCircle size={15} /> WhatsApp</a><a className="share-button share-fb" href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`} target="_blank" rel="noreferrer"><Facebook size={15} /> Facebook</a><button className="share-button share-copy" onClick={copyLink}>{copied ? <Check size={15} /> : <Copy size={15} />} {copied ? "Tersalin" : "Salin tautan"}</button></div>;
}
