# TODO Kilas Bimais Touna

## Portal publik dan navigasi
- [x] Situs bernama “Kilas Bimais Touna” berbahasa Indonesia.
- [x] Portal mengabarkan berbagai kegiatan Bimas Islam dan KUA se-Kabupaten Tojo Una Una.
- [x] Beranda menampilkan berita utama, berita terbaru, kategori, foto, dan video.
- [x] Tersedia daftar berita dan halaman detail artikel dengan judul, tanggal, penulis, isi berita, serta media pendukung.
- [x] Navigasi/kategori tersedia untuk berita kegiatan Bimas Islam dan KUA di wilayah Kabupaten Tojo Una Una.
- [x] Tampilan responsif untuk komputer dan perangkat seluler.
- [x] Logo resmi Kementerian Agama ditampilkan sebagai identitas pendamping.

## Akses dan akun
- [x] Tersedia halaman login untuk admin dan user dengan hak akses berbeda berdasarkan peran.
- [x] Admin dapat menambah akun user.
- [x] Admin dapat mengubah username dan password akun user.
- [x] Perubahan username dan password akun admin maupun user tersimpan permanen dan dapat digunakan pada login berikutnya.
- [x] Sesi login tidak bocor ke pengguna yang belum terautentikasi.

## Berita dan media
- [x] Admin dapat membuat, mengedit, menerbitkan, dan menghapus berita.
- [x] Foto utama berita dapat dipilih langsung dari perangkat melalui formulir berita, diunggah ke storage proyek, lalu dipakai sebagai gambar artikel tanpa menempelkan link foto.
- [x] Admin dan user yang telah login dapat mengunggah foto dan video untuk digunakan dalam berita.
- [x] Media tersimpan sebagai aset durable dan tercatat di indeks aplikasi.
- [x] Berita yang dihapus tidak lagi dikembalikan sebagai konten fallback dan langsung hilang dari daftar publik setelah data diperbarui.

## Berbagi
- [x] Halaman artikel memiliki tombol berbagi ke WhatsApp.
- [x] Halaman artikel memiliki tombol berbagi ke Facebook.
