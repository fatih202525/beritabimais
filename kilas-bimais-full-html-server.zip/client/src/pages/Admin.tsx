import { FormEvent, useCallback, useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Check, ChevronRight, FileImage, FilePlus2, LayoutDashboard, LayoutTemplate, LoaderCircle, LogOut, Newspaper, Plus, Save, Settings2, ShieldCheck, Trash2, Upload, UserRound, Users, Video, X } from "lucide-react";
import { Link } from "wouter";

type AdminUser = { id: number; username: string; role: "admin" | "editor"; createdAt?: string };
type MediaAsset = { id: number; name: string; mediaType: "image" | "video"; mimeType: string; url: string; byteSize: number; createdAt: string };
type Article = { id: number; slug: string; title: string; summary: string | null; content: string; category: string; status: "draft" | "published"; mediaIds: string | null; media: MediaAsset[]; createdAt: string; updatedAt: string; publishedAt: string | null };
type Layout = { storyLayout: "grid" | "list" | "compact"; showFeaturedStory: boolean; showCategoryNav: boolean; compactHeader: boolean; accent: "green" | "blue" | "gold" };
type Section = "overview" | "news" | "media" | "layout" | "account";
type Draft = { id?: number; slug: string; title: string; summary: string; content: string; category: string; status: "draft" | "published"; mediaIds: number[] };

const emptyDraft = (): Draft => ({ slug: "", title: "", summary: "", content: "", category: "Berita", status: "draft", mediaIds: [] });
const defaultLayout: Layout = { storyLayout: "grid", showFeaturedStory: true, showCategoryNav: true, compactHeader: false, accent: "green" };
let csrfToken = "";

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (options.method && options.method !== "GET" && csrfToken) headers.set("X-Kilas-CSRF", csrfToken);
  const response = await fetch(path, { ...options, headers, credentials: "include" });
  const data = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new Error(data.error || "Permintaan gagal.");
  return data;
}

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}
function fileSize(size: number) {
  return size >= 1024 * 1024 ? `${(size / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(size / 1024))} KB`;
}

export default function Admin() {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [checking, setChecking] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [section, setSection] = useState<Section>("overview");
  const [articles, setArticles] = useState<Article[]>([]);
  const [media, setMedia] = useState<MediaAsset[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [layout, setLayout] = useState<Layout>(defaultLayout);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [dataError, setDataError] = useState("");
  const [draft, setDraft] = useState<Draft>(emptyDraft());
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState<"admin" | "editor">("editor");
  const [currentPassword, setCurrentPassword] = useState("");
  const [accountUsername, setAccountUsername] = useState("");
  const [accountPassword, setAccountPassword] = useState("");

  const loadData = useCallback(async (user: AdminUser) => {
    setDataError("");
    const [newsResult, mediaResult, settingsResult] = await Promise.all([
      request<Article[]>("/api/admin/news"),
      request<MediaAsset[]>("/api/admin/media"),
      request<{ layout: Layout }>("/api/admin/settings"),
    ]);
    setArticles(newsResult);
    setMedia(mediaResult);
    setLayout(settingsResult.layout);
    if (user.role === "admin") {
      const userResult = await request<AdminUser[]>("/api/admin/users");
      setUsers(userResult);
    }
  }, []);

  useEffect(() => {
    let active = true;
    request<{ authenticated: boolean; admin?: AdminUser; csrfToken?: string }>("/api/admin/me")
      .then(async result => {
        if (!active) return;
        if (result.authenticated && result.admin && result.csrfToken) {
          csrfToken = result.csrfToken;
          setAdmin(result.admin);
          setAccountUsername(result.admin.username);
          await loadData(result.admin);
        }
      })
      .catch(() => { if (active) setDataError("Layanan admin belum dapat dijangkau. Coba muat ulang halaman."); })
      .finally(() => { if (active) setChecking(false); });
    return () => { active = false; };
  }, [loadData]);

  const flash = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 3500);
  };

  async function submitLogin(event: FormEvent) {
    event.preventDefault();
    setLoginBusy(true);
    setLoginError("");
    try {
      const result = await request<{ admin: AdminUser; csrfToken: string }>("/api/admin/login", { method: "POST", body: JSON.stringify({ username, password }) });
      csrfToken = result.csrfToken;
      setAdmin(result.admin);
      setAccountUsername(result.admin.username);
      setPassword("");
      await loadData(result.admin);
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "Tidak dapat masuk.");
    } finally {
      setLoginBusy(false);
    }
  }

  async function logout() {
    try { await request("/api/admin/logout", { method: "POST", body: "{}" }); } catch { /* still clear local admin state */ }
    csrfToken = "";
    setAdmin(null);
    setSection("overview");
  }

  function startEdit(article?: Article) {
    if (!article) { setDraft(emptyDraft()); return; }
    let ids: number[] = [];
    try { ids = JSON.parse(article.mediaIds || "[]").map(Number).filter(Number.isFinite); } catch { ids = article.media.map(item => item.id); }
    setDraft({ id: article.id, slug: article.slug, title: article.title, summary: article.summary || "", content: article.content, category: article.category, status: article.status, mediaIds: ids });
  }

  async function saveNews(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const payload = { slug: draft.slug, title: draft.title, summary: draft.summary, content: draft.content, category: draft.category, status: draft.status, mediaIds: draft.mediaIds };
      if (draft.id) await request(`/api/admin/news/${draft.id}`, { method: "PUT", body: JSON.stringify(payload) });
      else await request("/api/admin/news", { method: "POST", body: JSON.stringify(payload) });
      await loadData(admin!);
      flash(draft.status === "published" ? "Berita tersimpan dan diterbitkan." : "Draf berita tersimpan.");
      setDraft(emptyDraft());
    } catch (error) {
      flash(error instanceof Error ? error.message : "Berita gagal disimpan.");
    } finally { setBusy(false); }
  }

  async function removeNews(article: Article) {
    if (!window.confirm(`Hapus berita “${article.title}”?`)) return;
    try {
      await request(`/api/admin/news/${article.id}`, { method: "DELETE", body: "{}" });
      await loadData(admin!);
      if (draft.id === article.id) setDraft(emptyDraft());
      flash("Berita dihapus.");
    } catch (error) { flash(error instanceof Error ? error.message : "Berita gagal dihapus."); }
  }

  async function uploadFiles(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const file of Array.from(files)) {
        if (file.size > 40 * 1024 * 1024) throw new Error(`${file.name}: batas ukuran 40 MB.`);
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => typeof reader.result === "string" ? resolve(reader.result.split(",")[1] || "") : reject(new Error("Berkas gagal dibaca."));
          reader.onerror = () => reject(new Error("Berkas gagal dibaca."));
          reader.readAsDataURL(file);
        });
        const asset = await request<MediaAsset>("/api/admin/media", { method: "POST", body: JSON.stringify({ name: file.name, mimeType: file.type, data: dataUrl }) });
        setMedia(previous => [asset, ...previous]);
        setDraft(previous => ({ ...previous, mediaIds: [...new Set([...previous.mediaIds, asset.id])] }));
      }
      flash("Media berhasil diunggah dan dipilih untuk berita.");
    } catch (error) {
      flash(error instanceof Error ? error.message : "Upload gagal.");
    } finally { setBusy(false); }
  }

  async function saveLayout(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await request<{ layout: Layout }>("/api/admin/settings", { method: "PUT", body: JSON.stringify({ layout }) });
      setLayout(result.layout);
      flash("Tata letak tersimpan. Perubahan langsung digunakan di halaman publik.");
    } catch (error) { flash(error instanceof Error ? error.message : "Tata letak gagal disimpan."); }
    finally { setBusy(false); }
  }

  async function addUser(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      await request("/api/admin/users", { method: "POST", body: JSON.stringify({ username: newUsername, password: newPassword, role: newRole }) });
      setNewUsername(""); setNewPassword("");
      await loadData(admin!);
      flash("Pengguna baru berhasil ditambahkan.");
    } catch (error) { flash(error instanceof Error ? error.message : "Pengguna gagal ditambahkan."); }
    finally { setBusy(false); }
  }

  async function saveAccount(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await request<{ admin: AdminUser }>("/api/admin/account", { method: "PATCH", body: JSON.stringify({ currentPassword, username: accountUsername, password: accountPassword }) });
      setAdmin(result.admin);
      setCurrentPassword(""); setAccountPassword("");
      flash("Akun berhasil diperbarui.");
    } catch (error) { flash(error instanceof Error ? error.message : "Akun gagal diperbarui."); }
    finally { setBusy(false); }
  }

  if (checking) return <div className="admin-loading"><LoaderCircle size={24} className="spin" /><span>Memeriksa sesi admin…</span></div>;

  if (!admin) return <main className="login-screen">
    <a href="/" className="login-back"><ArrowLeft size={15} /> Kembali ke situs</a>
    <div className="login-card">
      <div className="login-logo"><img src="/kemenag-logo.png" alt="Lambang Kementerian Agama" /><span>KILAS<br /><b>BIMAIS TOUNA</b></span></div>
      <span className="panel-kicker">AREA TERBATAS REDAKSI</span>
      <h1>Masuk admin</h1>
      <p className="login-subtitle">Masuk untuk mengelola berita dan informasi portal.</p>
      {dataError && <div className="form-error">{dataError}</div>}
      {loginError && <div className="form-error">{loginError}</div>}
      <form onSubmit={submitLogin} className="form-stack">
        <label>Username<input value={username} onChange={event => setUsername(event.target.value)} autoComplete="username" required /></label>
        <label>Password<input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete="current-password" required /></label>
        <button className="solid-button login-submit" type="submit" disabled={loginBusy}>{loginBusy ? <LoaderCircle size={17} className="spin" /> : <ShieldCheck size={17} />} Masuk ke panel admin</button>
      </form>
      <div className="login-security"><ShieldCheck size={15} /> Akses hanya untuk pengguna redaksi terdaftar.</div>
    </div>
    <p className="login-footer">Seksi Bimas Islam · Kantor Kementerian Agama Kab. Tojo Una Una</p>
  </main>;

  const nav: { id: Section; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Ringkasan", icon: LayoutDashboard },
    { id: "news", label: "Kelola berita", icon: Newspaper },
    { id: "media", label: "Foto & video", icon: FileImage },
    ...(admin.role === "admin" ? [{ id: "layout" as Section, label: "Tata letak", icon: LayoutTemplate }] : []),
    { id: "account", label: "Akun & pengguna", icon: Users },
  ];
  const publishedCount = articles.filter(item => item.status === "published").length;
  return <div className="admin-shell">
    <aside className="admin-sidebar">
      <a href="/" className="admin-brand"><img src="/kemenag-logo.png" alt="" /><span><b>KILAS BIMAIS</b><small>TOUNA · REDAKSI</small></span></a>
      <div className="sidebar-label">RUANG KERJA</div>
      <nav className="admin-nav">{nav.map(item => {
        const Icon = item.icon;
        if (item.id === "account" && admin.role !== "admin") return <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><Icon size={18} /><span>Akun saya</span><ChevronRight size={15} /></button>;
        return <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><Icon size={18} /><span>{item.label}</span>{item.id === "news" && <em>{articles.length}</em>}</button>;
      })}</nav>
      <div className="sidebar-bottom"><div className="signed-user"><div className="user-avatar">{admin.username.slice(0, 1).toUpperCase()}</div><span><b>{admin.username}</b><small>{admin.role === "admin" ? "Administrator" : "Editor"}</small></span></div><button className="sidebar-logout" onClick={logout}><LogOut size={16} /> Keluar</button></div>
    </aside>
    <main className="admin-main">
      <header className="admin-topbar"><div><span>PORTAL REDAKSI</span><strong>{nav.find(item => item.id === section)?.label || "Akun saya"}</strong></div><div className="admin-top-actions"><a href="/" target="_blank" rel="noreferrer">Lihat situs <ArrowRight size={14} /></a><button aria-label="Keluar" onClick={logout}><LogOut size={16} /></button></div></header>
      <div className="admin-content">
        {notice && <div className="admin-toast"><Check size={16} /> {notice}<button onClick={() => setNotice("")} aria-label="Tutup"><X size={15} /></button></div>}
        {dataError && <div className="admin-alert">{dataError} <button onClick={() => loadData(admin)}>Coba lagi</button></div>}
        {section === "overview" && <section>
          <div className="welcome-heading"><div><span className="panel-kicker">SELAMAT BEKERJA</span><h1>Ruang redaksi</h1><p>Kelola kabar dan tampilan Kilas Bimais Touna dari satu tempat.</p></div><button className="solid-button" onClick={() => { startEdit(); setSection("news"); }}><Plus size={17} /> Tulis berita</button></div>
          <div className="stats-row"><div className="stat-card"><span>Semua berita</span><strong>{articles.length}</strong><small>Konten tersimpan</small></div><div className="stat-card"><span>Berita terbit</span><strong>{publishedCount}</strong><small>Tampil di situs publik</small></div><div className="stat-card"><span>Draf</span><strong>{articles.length - publishedCount}</strong><small>Belum diterbitkan</small></div><div className="stat-card"><span>Foto & video</span><strong>{media.length}</strong><small>Di pustaka media</small></div></div>
          <div className="panel-card overview-news"><div className="panel-title-row"><div><span className="panel-kicker">PEMUTAKHIRAN</span><h2>Berita terakhir dikelola</h2></div><button className="text-button" onClick={() => setSection("news")}>Lihat semua <ArrowRight size={15} /></button></div>
            {articles.length === 0 ? <div className="admin-empty"><Newspaper size={22} /><p>Belum ada berita. Mulai dengan membuat berita pertama.</p><button className="outline-button" onClick={() => { startEdit(); setSection("news"); }}><Plus size={15} /> Buat berita</button></div> : articles.slice(0, 5).map(item => <div className="overview-row" key={item.id}><span className={`status-dot ${item.status}`} /><div><b>{item.title}</b><small>{item.category} · Diperbarui {dateLabel(item.updatedAt)}</small></div><span className={`status-pill ${item.status}`}>{item.status === "published" ? "Terbit" : "Draf"}</span><button className="icon-button" onClick={() => { startEdit(item); setSection("news"); }} aria-label="Edit berita"><ChevronRight size={17} /></button></div>)}
          </div>
          <div className="admin-help-strip"><Settings2 size={18} /><span>Atur tampilan situs</span><p>Ubah model daftar, aksen warna, dan elemen beranda di menu Tata letak.</p><button className="text-button" onClick={() => setSection("layout")}>Buka editor <ArrowRight size={15} /></button></div>
        </section>}

        {section === "news" && <section>
          <div className="welcome-heading"><div><span className="panel-kicker">PENGELOLAAN KONTEN</span><h1>Kelola berita</h1><p>Buat draf, terbitkan berita, dan atur foto atau video pendukung.</p></div><button className="solid-button" onClick={() => startEdit()}><FilePlus2 size={17} /> Berita baru</button></div>
          <div className="news-workspace">
            <div className="panel-card news-list-panel"><div className="panel-title-row"><div><h2>Daftar berita</h2><span className="muted-caption">{articles.length} berita</span></div></div>
              {articles.length === 0 && <div className="admin-empty"><Newspaper size={21} /><p>Belum ada berita tersimpan.</p></div>}
              {articles.map(item => <div className={`news-manage-row ${draft.id === item.id ? "selected" : ""}`} key={item.id}><div className="news-row-thumb">{item.media[0]?.mediaType === "image" ? <img src={item.media[0].url} alt="" /> : item.media[0]?.mediaType === "video" ? <Video size={18} /> : <Newspaper size={18} />}</div><div className="news-row-info"><b>{item.title}</b><small>{dateLabel(item.updatedAt)} · {item.category}</small><span className={`status-pill ${item.status}`}>{item.status === "published" ? "Terbit" : "Draf"}</span></div><div className="row-actions"><button className="icon-button" aria-label="Edit berita" onClick={() => startEdit(item)}><Settings2 size={16} /></button><button className="icon-button danger" aria-label="Hapus berita" onClick={() => removeNews(item)}><Trash2 size={15} /></button></div></div>)}
            </div>
            <form className="panel-card news-editor" onSubmit={saveNews}>
              <div className="panel-title-row"><div><span className="panel-kicker">EDITOR BERITA</span><h2>{draft.id ? "Edit konten" : "Konten baru"}</h2></div>{draft.id && <button type="button" className="icon-button" onClick={() => startEdit()} aria-label="Batalkan edit"><X size={17} /></button>}</div>
              <label className="admin-field">Judul berita<input required minLength={5} maxLength={240} value={draft.title} onChange={event => setDraft({ ...draft, title: event.target.value })} placeholder="Tulis judul berita" /></label>
              <div className="field-split"><label className="admin-field">Kategori<input value={draft.category} maxLength={80} onChange={event => setDraft({ ...draft, category: event.target.value })} placeholder="Berita" /></label><label className="admin-field">Status<select value={draft.status} onChange={event => setDraft({ ...draft, status: event.target.value as Draft["status"] })}><option value="draft">Simpan sebagai draf</option><option value="published">Terbitkan sekarang</option></select></label></div>
              <label className="admin-field">Tautan berita (slug)<input value={draft.slug} onChange={event => setDraft({ ...draft, slug: event.target.value })} placeholder="Dibuat otomatis dari judul" /></label>
              <label className="admin-field">Ringkasan<textarea rows={2} maxLength={1200} value={draft.summary} onChange={event => setDraft({ ...draft, summary: event.target.value })} placeholder="Ringkasan singkat untuk halaman utama" /></label>
              <label className="admin-field">Isi berita<textarea required minLength={10} maxLength={14000} rows={8} value={draft.content} onChange={event => setDraft({ ...draft, content: event.target.value })} placeholder="Tulis isi berita di sini. Pisahkan paragraf dengan baris kosong." /><small>Maksimal 14.000 karakter.</small></label>
              <div className="media-picker-heading"><div><b>Foto atau video</b><small>Ukuran maksimum 40 MB per berkas.</small></div><label className="upload-button"><Upload size={15} /> Unggah media<input type="file" hidden multiple accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" onChange={event => { void uploadFiles(event.target.files); event.target.value = ""; }} /></label></div>
              {media.length > 0 ? <div className="media-picker-grid">{media.map(item => { const selected = draft.mediaIds.includes(item.id); return <button key={item.id} type="button" className={`media-pick ${selected ? "picked" : ""}`} onClick={() => setDraft(previous => ({ ...previous, mediaIds: selected ? previous.mediaIds.filter(id => id !== item.id) : [...previous.mediaIds, item.id] }))}>
                {item.mediaType === "image" ? <img src={item.url} alt={item.name} /> : <div className="video-thumb"><Video size={22} /></div>}<span>{selected && <Check size={13} />}{item.name}</span></button>; })}</div> : <div className="upload-empty"><FileImage size={17} /> Pustaka media masih kosong. Unggah foto atau video untuk mulai.</div>}
              <div className="editor-actions"><button type="button" className="outline-button" onClick={() => setDraft(emptyDraft())}>Bersihkan</button><button type="submit" className="solid-button" disabled={busy}>{busy ? <LoaderCircle size={16} className="spin" /> : <Save size={16} />}{draft.status === "published" ? "Simpan & terbitkan" : "Simpan draf"}</button></div>
            </form>
          </div>
        </section>}

        {section === "media" && <section>
          <div className="welcome-heading"><div><span className="panel-kicker">ARSIP DIGITAL</span><h1>Foto & video</h1><p>Kelola media yang dapat dipilih saat membuat berita.</p></div><label className="solid-button media-upload-main"><Upload size={16} /> Unggah berkas<input type="file" hidden multiple accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" onChange={event => { void uploadFiles(event.target.files); event.target.value = ""; }} /></label></div>
          <div className="media-library-count"><FileImage size={17} /> {media.length} berkas tersimpan <span>·</span> media terhubung dengan berita akan tampil di halaman detail.</div>
          {media.length === 0 ? <div className="panel-card admin-empty media-empty"><FileImage size={28} /><h3>Belum ada media</h3><p>Unggah foto JPG, PNG, WebP, GIF, atau video MP4/WebM. Maksimum 40 MB per berkas.</p></div> : <div className="media-library-grid">{media.map(item => <article className="library-media-card" key={item.id}>{item.mediaType === "image" ? <img src={item.url} alt={item.name} loading="lazy" /> : <div className="library-video"><video src={item.url} preload="metadata" /><Video size={22} /></div>}<div><b title={item.name}>{item.name}</b><span>{item.mediaType === "image" ? "Foto" : "Video"} · {fileSize(item.byteSize)}</span><small>Diunggah {dateLabel(item.createdAt)}</small></div></article>)}</div>}
        </section>}

        {section === "layout" && <section>
          <div className="welcome-heading"><div><span className="panel-kicker">PENGATURAN PUBLIK</span><h1>Tata letak situs</h1><p>Pilih susunan berita dan elemen yang tampil di halaman utama.</p></div></div>
          <form className="layout-settings" onSubmit={saveLayout}>
            <div className="panel-card settings-block"><span className="panel-kicker">SUSUNAN BERITA</span><h2>Gaya daftar artikel</h2><p>Pengaturan ini langsung memengaruhi halaman utama.</p><div className="layout-choice-row">{(["grid", "list", "compact"] as const).map(mode => <button type="button" key={mode} className={`layout-choice ${layout.storyLayout === mode ? "selected" : ""}`} onClick={() => setLayout({ ...layout, storyLayout: mode })}><span className={`choice-preview ${mode}`}><i /><i /><i /></span><b>{mode === "grid" ? "Kartu editorial" : mode === "list" ? "Daftar berita" : "Ringkas"}</b><small>{mode === "grid" ? "Kartu lebar dengan ringkasan" : mode === "list" ? "Baris horizontal dengan gambar" : "Tampilan padat"}</small></button>)}</div></div>
            <div className="panel-card settings-block"><span className="panel-kicker">ELEMEN BERANDA</span><h2>Atur komponen yang ditampilkan</h2><ToggleRow title="Berita unggulan" description="Tampilkan berita terbaru sebagai sorotan utama." checked={layout.showFeaturedStory} onChange={value => setLayout({ ...layout, showFeaturedStory: value })} /><ToggleRow title="Navigasi utama" description="Tampilkan menu beranda, berita terbaru, dan tentang kami." checked={layout.showCategoryNav} onChange={value => setLayout({ ...layout, showCategoryNav: value })} /><ToggleRow title="Header ringkas" description="Kurangi tinggi area identitas di halaman publik." checked={layout.compactHeader} onChange={value => setLayout({ ...layout, compactHeader: value })} /></div>
            <div className="panel-card settings-block"><span className="panel-kicker">AKSEN WARNA</span><h2>Pilih aksen portal</h2><p>Warna tetap menjaga karakter institusional; hanya aksen tombol dan label yang berubah.</p><div className="accent-choices">{(["green", "gold", "blue"] as const).map(color => <button type="button" key={color} onClick={() => setLayout({ ...layout, accent: color })} className={`accent-choice ${color} ${layout.accent === color ? "selected" : ""}`}><i />{color === "green" ? "Hijau institusi" : color === "gold" ? "Emas hangat" : "Biru layanan"}{layout.accent === color && <Check size={15} />}</button>)}</div></div>
            <div className="save-settings-row"><span>Perubahan disimpan di basis data dan tetap tampil setelah halaman dimuat ulang.</span><button className="solid-button" type="submit" disabled={busy}>{busy ? <LoaderCircle size={16} className="spin" /> : <Save size={16} />} Simpan tata letak</button></div>
          </form>
        </section>}

        {section === "account" && <section>
          <div className="welcome-heading"><div><span className="panel-kicker">AKSES & KEAMANAN</span><h1>{admin.role === "admin" ? "Akun & pengguna" : "Akun saya"}</h1><p>Ubah kredensial akun atau tambahkan anggota redaksi.</p></div></div>
          <div className="account-grid">
            <form className="panel-card account-form" onSubmit={saveAccount}><div className="settings-heading-icon"><UserRound size={18} /><div><h2>Ubah akun saya</h2><p>Verifikasi sandi saat ini sebelum menyimpan.</p></div></div><label className="admin-field">Username baru<input required value={accountUsername} onChange={event => setAccountUsername(event.target.value)} autoComplete="username" minLength={3} maxLength={32} /><small>3–32 karakter: huruf kecil, angka, titik, - atau _.</small></label><label className="admin-field">Sandi baru<input type="password" value={accountPassword} onChange={event => setAccountPassword(event.target.value)} autoComplete="new-password" minLength={12} placeholder="Kosongkan jika tidak diubah" /><small>Minimal 12 karakter.</small></label><label className="admin-field">Sandi saat ini<input type="password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} autoComplete="current-password" required /></label><button type="submit" className="solid-button" disabled={busy}><Save size={16} /> Simpan perubahan akun</button></form>
            {admin.role === "admin" && <form className="panel-card account-form" onSubmit={addUser}><div className="settings-heading-icon"><Users size={18} /><div><h2>Tambah pengguna</h2><p>Beri akses admin penuh atau peran editor.</p></div></div><label className="admin-field">Username<input required value={newUsername} onChange={event => setNewUsername(event.target.value)} autoComplete="off" minLength={3} maxLength={32} placeholder="contoh: redaksi01" /></label><label className="admin-field">Sandi awal<input type="password" required value={newPassword} onChange={event => setNewPassword(event.target.value)} autoComplete="new-password" minLength={10} placeholder="Minimal 10 karakter" /></label><label className="admin-field">Peran<select value={newRole} onChange={event => setNewRole(event.target.value as "admin" | "editor")}><option value="editor">Editor berita</option><option value="admin">Administrator</option></select></label><button type="submit" className="solid-button" disabled={busy}><Plus size={16} /> Tambahkan user</button></form>}
          </div>
          {admin.role === "admin" && <div className="panel-card users-table"><div className="panel-title-row"><div><span className="panel-kicker">DAFTAR AKSES</span><h2>Pengguna admin</h2></div><span className="user-count">{users.length} pengguna</span></div>{users.map(person => <div className="user-table-row" key={person.id}><div className="user-avatar small">{person.username.slice(0, 1).toUpperCase()}</div><b>{person.username}{person.id === admin.id && <small className="you-label">Anda</small>}</b><span className={`role-pill ${person.role}`}>{person.role === "admin" ? "Administrator" : "Editor"}</span><span className="user-since">{person.createdAt ? dateLabel(person.createdAt) : "—"}</span></div>)}</div>}
        </section>}
      </div>
    </main>
    <nav className="mobile-admin-nav">{nav.map(item => { const Icon = item.icon; return <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><Icon size={18} /><span>{item.id === "overview" ? "Home" : item.id === "news" ? "Berita" : item.id === "media" ? "Media" : item.id === "layout" ? "Layout" : "Akun"}</span></button>; })}</nav>
  </div>;
}

function ToggleRow({ title, description, checked, onChange }: { title: string; description: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <div className="toggle-row"><div><b>{title}</b><small>{description}</small></div><button type="button" role="switch" aria-checked={checked} className={`switch ${checked ? "on" : ""}`} onClick={() => onChange(!checked)}><i /></button></div>;
}
