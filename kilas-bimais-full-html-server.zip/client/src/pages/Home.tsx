import { useEffect, useState } from "react";
import { Link, useRoute } from "wouter";
import { ArrowLeft, ArrowUpRight, CalendarDays, Check, Copy, Facebook, FileText, Instagram, LoaderCircle, Share2, Video } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/PublicSite";

type Media = { id: number; name: string; mediaType: "image" | "video"; url: string };
type Article = { id: number; slug: string; title: string; summary: string | null; content: string; category: string; createdAt: string; publishedAt: string | null; media: Media[] };
type Layout = { storyLayout: "grid" | "list" | "compact"; showFeaturedStory: boolean; showCategoryNav: boolean; compactHeader: boolean; accent: "green" | "blue" | "gold" };
const initialLayout: Layout = { storyLayout: "grid", showFeaturedStory: true, showCategoryNav: true, compactHeader: false, accent: "green" };

async function publicGet<T>(path: string): Promise<T> {
  const response = await fetch(path, { credentials: "include", headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error("Informasi tidak dapat dimuat saat ini.");
  return response.json() as Promise<T>;
}

function formatDate(value: string | null | undefined) {
  if (!value) return "";
  return new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric" }).format(new Date(value));
}

function MediaView({ media, className = "" }: { media?: Media[]; className?: string }) {
  const item = media?.[0];
  if (!item) return <div className={`story-placeholder ${className}`}><span>KILAS<br />BIMAIS<br /><b>TOUNA</b></span></div>;
  if (item.mediaType === "video") return <div className={`story-media-video ${className}`}><video src={item.url} controls preload="metadata" aria-label={item.name} /><span><Video size={14} /> Video</span></div>;
  return <img className={`story-cover ${className}`} src={item.url} alt={item.name} loading="lazy" />;
}

function ShareLinks({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);
  const share = (platform: "whatsapp" | "facebook") => {
    const url = window.location.href;
    const target = platform === "whatsapp"
      ? `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`
      : `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
    window.open(target, "_blank", "noopener,noreferrer,width=760,height=560");
  };
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      window.prompt("Salin tautan berita ini:", window.location.href);
    }
  };
  return <div className="share-row" aria-label="Bagikan berita">
    <span><Share2 size={15} /> Bagikan</span>
    <button type="button" onClick={() => share("whatsapp")} className="share-button share-wa">WhatsApp</button>
    <button type="button" onClick={() => share("facebook")} className="share-button share-fb"><Facebook size={14} /> Facebook</button>
    <button type="button" onClick={copy} className="share-button share-ig">{copied ? <Check size={14} /> : <Instagram size={14} />}{copied ? "Tautan tersalin" : "Salin untuk Instagram"}</button>
  </div>;
}

function ArticleCard({ article, featured = false }: { article: Article; featured?: boolean }) {
  return <article className={`article-card ${featured ? "article-featured" : ""}`}>
    <Link href={`/berita/${article.slug}`} className="article-image-link" aria-label={`Baca ${article.title}`}>
      <MediaView media={article.media} />
      <span className="article-category">{article.category}</span>
    </Link>
    <div className="article-card-body">
      <div className="article-meta"><CalendarDays size={13} /> {formatDate(article.publishedAt || article.createdAt)}</div>
      <h2><Link href={`/berita/${article.slug}`}>{article.title}</Link></h2>
      {article.summary && <p>{article.summary}</p>}
      <Link className="read-link" href={`/berita/${article.slug}`}>Baca selengkapnya <ArrowUpRight size={15} /></Link>
    </div>
  </article>;
}

export default function Home() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [layout, setLayout] = useState<Layout>(initialLayout);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([publicGet<Article[]>("/api/public/news"), publicGet<{ layout: Layout }>("/api/public/settings")])
      .then(([items, settings]) => { if (active) { setArticles(items); setLayout(settings.layout); } })
      .catch(() => { if (active) setError("Berita belum dapat dimuat. Periksa kembali sebentar lagi."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const featured = layout.showFeaturedStory ? articles[0] : undefined;
  return <div className={`public-site accent-${layout.accent}`}>
    <SiteHeader compact={layout.compactHeader} showNavigation={layout.showCategoryNav} />
    <main>
      <section className="intro-band">
        <div className="site-container intro-inner">
          <div><div className="eyebrow"><span /> KEMENTERIAN AGAMA REPUBLIK INDONESIA</div><h1>Kabar Bimas Islam<br /><em>Tojo Una Una</em></h1><p>Informasi kegiatan, layanan, dan kabar terkini dari Seksi Bimas Islam.</p></div>
          <div className="intro-seal"><span>IKHLAS<br />BERAMAL</span><i>✦</i></div>
          <div className="intro-index"><small>PORTAL BERITA</small><strong>TOUNA</strong><span>PROVINSI SULAWESI TENGAH</span></div>
        </div>
      </section>
      <section className="news-section site-container" id="berita">
        <div className="section-heading"><div><span className="section-kicker">KILAS BIMAIS TOUNA</span><h2>Berita terbaru</h2></div><span className="section-date">{new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric" }).format(new Date())}</span></div>
        {loading && <div className="loading-line"><LoaderCircle className="spin" size={19} /> Memuat berita terbaru</div>}
        {!loading && error && <div className="empty-state error-state"><FileText size={26} /><h3>Belum dapat terhubung</h3><p>{error}</p><button className="outline-button" onClick={() => window.location.reload()}>Muat ulang</button></div>}
        {!loading && !error && articles.length === 0 && <div className="empty-state"><div className="empty-icon"><FileText size={25} /></div><span className="section-kicker">RUANG INFORMASI KAMI</span><h3>Belum ada berita yang diterbitkan</h3><p>Berita terbaru dari Seksi Bimas Islam akan ditampilkan di sini setelah redaksi menerbitkannya.</p><a href="/admin" className="empty-admin-link">Masuk ke halaman redaksi <ArrowUpRight size={15} /></a></div>}
        {!loading && !error && articles.length > 0 && <>
          {featured && <ArticleCard article={featured} featured />}
          {(featured ? articles.slice(1) : articles).length > 0 && <div className={`article-grid mode-${layout.storyLayout}`}>{(featured ? articles.slice(1) : articles).map(article => <ArticleCard article={article} key={article.id} />)}</div>}
        </>}
      </section>
      <section className="redaction-strip"><div className="site-container"><div><span className="strip-star">✦</span><p><small>RUANG REDAKSI</small><strong>Seksi Bimas Islam · Kemenag Tojo Una Una</strong></p></div><a href="/admin">Kelola informasi <ArrowUpRight size={15} /></a></div></section>
    </main>
    <SiteFooter />
  </div>;
}

export function ArticlePage() {
  const [, params] = useRoute<{ slug: string }>("/berita/:slug");
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [layout, setLayout] = useState<Layout>(initialLayout);
  useEffect(() => {
    if (!params?.slug) return;
    let active = true;
    Promise.all([
      publicGet<Article>(`/api/public/news/${encodeURIComponent(params.slug)}`),
      publicGet<{ layout: Layout }>("/api/public/settings"),
    ])
      .then(([item, settings]) => { if (active) { setArticle(item); setLayout(settings.layout); } })
      .catch(() => { if (active) setError("Berita tidak ditemukan atau belum diterbitkan."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [params?.slug]);

  return <div className={`public-site accent-${layout.accent}`}>
    <SiteHeader compact={layout.compactHeader} showNavigation={layout.showCategoryNav} />
    <main className="article-page site-container">
      <Link href="/" className="back-link"><ArrowLeft size={16} /> Kembali ke berita</Link>
      {loading && <div className="loading-line"><LoaderCircle className="spin" size={19} /> Memuat berita</div>}
      {!loading && error && <div className="empty-state article-error"><FileText size={25} /><h2>Berita tidak tersedia</h2><p>{error}</p><Link href="/" className="read-link">Lihat berita lainnya <ArrowUpRight size={15} /></Link></div>}
      {!loading && article && <article className="article-detail">
        <span className="article-category detail-category">{article.category}</span>
        <h1>{article.title}</h1>
        {article.summary && <p className="article-deck">{article.summary}</p>}
        <div className="detail-byline"><span>Seksi Bimas Islam · Kemenag Tojo Una Una</span><span><CalendarDays size={14} /> {formatDate(article.publishedAt || article.createdAt)}</span></div>
        {article.media?.length > 0 && <div className="detail-media">{article.media.map(asset => asset.mediaType === "video"
          ? <video key={asset.id} src={asset.url} controls preload="metadata" aria-label={asset.name} />
          : <img key={asset.id} src={asset.url} alt={asset.name} />)}</div>}
        <div className="article-content">{article.content.split(/\n{2,}/).map((paragraph, i) => <p key={i}>{paragraph}</p>)}</div>
        <ShareLinks title={article.title} />
      </article>}
      {!loading && !error && !article && <p className="empty-state">Berita tidak tersedia.</p>}
    </main>
    <SiteFooter />
  </div>;
}
