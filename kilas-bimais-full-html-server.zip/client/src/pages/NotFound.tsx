import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

const NOT_FOUND_PATH = "/404";

export default function NotFound() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) window.location.replace(NOT_FOUND_PATH);
    return () => robots.remove();
  }, []);

  return <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
    <Card className="w-full max-w-lg mx-4 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardContent className="pt-8 pb-8 text-center">
        <div className="flex justify-center mb-6"><div className="relative"><div className="absolute inset-0 bg-red-100 rounded-full animate-pulse" /><AlertCircle className="relative h-16 w-16 text-red-500" /></div></div>
        <h1 className="text-4xl font-bold text-slate-900 mb-2">404</h1>
        <h2 className="text-xl font-semibold text-slate-700 mb-4">Halaman tidak ditemukan</h2>
        <p className="text-slate-600 mb-8 leading-relaxed">Maaf, halaman yang Anda cari tidak tersedia.<br />Alamat mungkin berubah atau konten telah dihapus.</p>
        <Button onClick={() => setLocation("/")} className="bg-green-800 hover:bg-green-900 text-white px-6 py-2.5 rounded-lg transition-all duration-200 shadow-md"> <Home className="w-4 h-4 mr-2" />Kembali ke beranda</Button>
      </CardContent>
    </Card>
  </div>;
}
