import { Link } from "wouter";
import { ArrowRight, ShieldCheck } from "lucide-react";

export function SiteHeader({ compact = false, showNavigation = true }: { compact?: boolean; showNavigation?: boolean }) {
  return <>
    <div className="topline">
      <div className="site-container topline-inner">
        <span>Portal Informasi Bimas Islam</span>
        <span className="topline-location"><ShieldCheck size={13} /> Kantor Kementerian Agama Kabupaten Tojo Una Una</span>
      </div>
    </div>
    <header className={`site-header ${compact ? "site-header-compact" : ""}`}>
      <div className="site-container header-main">
        <Link href="/" className="brand-lockup" aria-label="Kilas Bimais Touna beranda">
          <img src="/kemenag-logo.png" alt="Lambang Kementerian Agama Republik Indonesia" className="kemenag-mark" />
          <span className="brand-divider" />
          <span className="brand-text"><strong>KILAS <span>BIMAIS</span></strong><small>TOUNA · INFORMASI &amp; LAYANAN</small></span>
        </Link>
        <a className="admin-link" href="/admin">Masuk Redaksi <ArrowRight size={15} /></a>
      </div>
      {showNavigation && <nav className="primary-nav">
        <div className="site-container nav-inner">
          <Link href="/" className="nav-active">BERANDA</Link>
          <a href="/#berita">BERITA TERBARU</a>
          <a href="/#tentang">TENTANG KAMI</a>
          <span className="nav-region">TOJO UNA UNA <i /></span>
        </div>
      </nav>}
    </header>
  </>;
}

export function SiteFooter() {
  return <footer className="site-footer" id="tentang">
    <div className="site-container footer-content">
      <div className="footer-brand">
        <img src="/kemenag-logo.png" alt="" />
        <div><strong>Kilas Bimais Touna</strong><span>Informasi Bimas Islam Kabupaten Tojo Una Una</span></div>
      </div>
      <div className="footer-address"><small>ALAMAT REDAKSI</small><p>Seksi Bimas Islam Kantor Kementerian Agama Kab. Tojo Una Una</p></div>
      <div className="footer-note">© {new Date().getFullYear()} Kilas Bimais Touna<br />Media informasi dan layanan masyarakat</div>
    </div>
    <div className="footer-bottom"><div className="site-container">Kementerian Agama Republik Indonesia <span>·</span> Ikhlas Beramal</div></div>
  </footer>;
}
