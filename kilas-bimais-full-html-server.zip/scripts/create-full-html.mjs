import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const publicDir = path.resolve("dist/public");
const htmlPath = path.join(publicDir, "index.html");
let html = await readFile(htmlPath, "utf8");

const cssMatch = html.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/i);
const jsMatch = html.match(/<script\b[^>]*type="module"[^>]*src="([^"]+\.js)"[^>]*><\/script>/i);
if (!cssMatch || !jsMatch) throw new Error("Berkas CSS/JS produksi tidak ditemukan di index.html.");

const [css, js] = await Promise.all([
  readFile(path.join(publicDir, cssMatch[1].replace(/^\//, "")), "utf8"),
  readFile(path.join(publicDir, jsMatch[1].replace(/^\//, "")), "utf8"),
]);

html = html
  .replace(cssMatch[0], () => `<style>\n${css.replace(/<\/style/gi, "<\\/style")}\n</style>`)
  .replace(jsMatch[0], () => `<script type="module">\n${js.replace(/<\/script/gi, "<\\/script")}\n</script>`)
  .replace(/<title>.*?<\/title>/i, "<title>Kilas Bimais Touna | Versi Full HTML</title>");

const outputPath = path.join(publicDir, "kilas-bimais-full.html");
await writeFile(outputPath, html, "utf8");
const previewPath = path.resolve("client/public/kilas-bimais-full.html");
await writeFile(previewPath, html, "utf8");
console.log(`Full HTML dibuat: ${outputPath} dan ${previewPath} (${Buffer.byteLength(html)} bytes)`);
