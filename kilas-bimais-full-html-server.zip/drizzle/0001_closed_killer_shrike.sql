CREATE TABLE `admin_sessions` (
	`sessionHash` varchar(64) NOT NULL,
	`adminId` int NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_sessions_sessionHash` PRIMARY KEY(`sessionHash`)
);
--> statement-breakpoint
CREATE TABLE `media_assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`mediaType` enum('image','video') NOT NULL,
	`mimeType` varchar(80) NOT NULL,
	`storageKey` varchar(500) NOT NULL,
	`url` varchar(700) NOT NULL,
	`byteSize` int NOT NULL,
	`uploadedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `media_assets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `portal_admins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(32) NOT NULL,
	`passwordHash` varchar(180) NOT NULL,
	`role` enum('admin','editor') NOT NULL DEFAULT 'admin',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `portal_admins_id` PRIMARY KEY(`id`),
	CONSTRAINT `portal_admins_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `portal_news` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(220) NOT NULL,
	`title` varchar(240) NOT NULL,
	`summary` text,
	`content` text NOT NULL,
	`category` varchar(80) NOT NULL DEFAULT 'Berita',
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`mediaIds` text,
	`authorId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`publishedAt` timestamp,
	CONSTRAINT `portal_news_id` PRIMARY KEY(`id`),
	CONSTRAINT `portal_news_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `site_settings` (
	`settingKey` varchar(80) NOT NULL,
	`settingValue` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_settings_settingKey` PRIMARY KEY(`settingKey`)
);
