import { createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import type { Express, Request, Response } from "express";
import { and, desc, eq, inArray } from "drizzle-orm";
import { parse } from "cookie";
import { getDb } from "./db";
import { storagePut } from "./storage";
import { adminSessions, mediaAssets, portalAdmins, portalNews, siteSettings } from "../drizzle/schema";

const SESSION_COOKIE = "kilas_bimais_session";
const SESSION_DAYS = 7;
const MAX_UPLOAD_BYTES = 40 * 1024 * 1024;
const DEFAULT_LAYOUT = {
  storyLayout: "grid",
  showFeaturedStory: true,
  showCategoryNav: true,
  compactHeader: false,
  accent: "green",
};
const attempts = new Map<string, { count: number; resetAt: number }>();

type Admin = typeof portalAdmins.$inferSelect;
type Session = { admin: Admin; sessionHash: string; rawToken: string };
type Handler = (req: Request, res: Response) => Promise<void>;

const endpoint = (handler: Handler) => (req: Request, res: Response) => {
  void handler(req, res).catch((error: unknown) => {
    const message = error instanceof Error ? error.message : "unknown";
    console.error("[Kilas API] Request failed:", message.slice(0, 180));
    if (!res.headersSent) res.status(500).json({ error: "Terjadi kendala. Silakan coba kembali." });
  });
};

function sha256(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function csrfFor(rawToken: string) {
  return createHmac("sha256", rawToken).update("kilas-bimais-csrf-v1").digest("hex");
}

function csrfIsValid(rawToken: string, presented: unknown) {
  if (typeof presented !== "string") return false;
  const expected = Buffer.from(csrfFor(rawToken), "hex");
  const actual = Buffer.from(presented, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function sessionCookie(rawToken: string) {
  return `${SESSION_COOKIE}=${rawToken}; Path=/; Max-Age=${SESSION_DAYS * 24 * 60 * 60}; HttpOnly; Secure; SameSite=None`;
}

function clearSessionCookie() {
  return `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=None`;
}

async function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  const key = await new Promise<Buffer>((resolve, reject) => {
    scrypt(password, salt, 64, (error, derived) => error ? reject(error) : resolve(derived as Buffer));
  });
  return `${salt}:${key.toString("hex")}`;
}

async function passwordMatches(password: string, saved: string) {
  const [salt, expectedHex] = saved.split(":");
  if (!salt || !expectedHex || !/^[a-f0-9]{128}$/i.test(expectedHex)) return false;
  const derived = await new Promise<Buffer>((resolve, reject) => {
    scrypt(password, salt, 64, (error, key) => error ? reject(error) : resolve(key as Buffer));
  });
  const expected = Buffer.from(expectedHex, "hex");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

function cleanAdmin(admin: Admin) {
  return { id: admin.id, username: admin.username, role: admin.role, createdAt: admin.createdAt };
}

function usernameValue(value: unknown) {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

function validUsername(value: string) {
  return /^[a-z0-9._-]{3,32}$/.test(value);
}

function safeMediaIds(value: unknown) {
  if (!Array.isArray(value)) return "[]";
  const ids = value.map(Number).filter(id => Number.isInteger(id) && id > 0).slice(0, 24);
  return JSON.stringify([...new Set(ids)]);
}

function readMediaIds(value: string | null) {
  try {
    const parsed = JSON.parse(value ?? "[]");
    return Array.isArray(parsed) ? parsed.map(Number).filter(id => Number.isInteger(id) && id > 0) : [];
  } catch {
    return [];
  }
}

async function currentSession(req: Request, res: Response, mutation = false): Promise<Session | null> {
  const rawToken = parse(req.headers.cookie ?? "")[SESSION_COOKIE];
  if (!rawToken || rawToken.length < 40) {
    if (mutation) res.status(401).json({ error: "Silakan masuk kembali." });
    return null;
  }
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const sessionHash = sha256(rawToken);
  const [savedSession] = await db.select().from(adminSessions).where(eq(adminSessions.sessionHash, sessionHash)).limit(1);
  if (!savedSession || savedSession.expiresAt.getTime() <= Date.now()) {
    if (savedSession) await db.delete(adminSessions).where(eq(adminSessions.sessionHash, sessionHash));
    if (mutation) res.status(401).json({ error: "Sesi berakhir. Silakan masuk kembali." });
    return null;
  }
  const [admin] = await db.select().from(portalAdmins).where(eq(portalAdmins.id, savedSession.adminId)).limit(1);
  if (!admin) {
    if (mutation) res.status(401).json({ error: "Akun tidak ditemukan." });
    return null;
  }
  if (mutation && !csrfIsValid(rawToken, req.headers["x-kilas-csrf"])) {
    res.status(403).json({ error: "Permintaan tidak dapat diverifikasi. Muat ulang halaman admin." });
    return null;
  }
  return { admin, sessionHash, rawToken };
}

function publicLayout(raw: string | undefined) {
  try {
    const value = raw ? JSON.parse(raw) as Record<string, unknown> : {};
    return {
      storyLayout: value.storyLayout === "list" || value.storyLayout === "compact" ? value.storyLayout : "grid",
      showFeaturedStory: value.showFeaturedStory !== false,
      showCategoryNav: value.showCategoryNav !== false,
      compactHeader: value.compactHeader === true,
      accent: value.accent === "gold" || value.accent === "blue" ? value.accent : "green",
    };
  } catch {
    return DEFAULT_LAYOUT;
  }
}

async function getStoredLayout() {
  const db = await getDb();
  if (!db) return DEFAULT_LAYOUT;
  const [row] = await db.select().from(siteSettings).where(eq(siteSettings.settingKey, "layout")).limit(1);
  return publicLayout(row?.settingValue);
}

function slugify(value: string) {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 210) || `berita-${Date.now()}`;
}

async function attachMedia<T extends { mediaIds: string | null }>(rows: T[]) {
  const ids = [...new Set(rows.flatMap(row => readMediaIds(row.mediaIds)))];
  const db = await getDb();
  if (!ids.length || !db) return rows.map(row => ({ ...row, media: [] as (typeof mediaAssets.$inferSelect)[] }));
  const assets = await db.select().from(mediaAssets).where(inArray(mediaAssets.id, ids));
  const byId = new Map(assets.map(asset => [asset.id, asset]));
  return rows.map(row => ({ ...row, media: readMediaIds(row.mediaIds).map(id => byId.get(id)).filter((asset): asset is typeof assets[number] => Boolean(asset)) }));
}

function publicAsset(asset: typeof mediaAssets.$inferSelect) {
  return { id: asset.id, name: asset.name, mediaType: asset.mediaType, mimeType: asset.mimeType, url: asset.url, byteSize: asset.byteSize, createdAt: asset.createdAt };
}

function detectMedia(bytes: Buffer): { mediaType: "image" | "video"; mimeType: string; extension: string } | null {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { mediaType: "image", mimeType: "image/jpeg", extension: "jpg" };
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return { mediaType: "image", mimeType: "image/png", extension: "png" };
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return { mediaType: "image", mimeType: "image/webp", extension: "webp" };
  if (bytes.length >= 6 && /^GIF8[79]a$/.test(bytes.toString("ascii", 0, 6))) return { mediaType: "image", mimeType: "image/gif", extension: "gif" };
  if (bytes.length >= 12 && bytes.toString("ascii", 4, 8) === "ftyp") return { mediaType: "video", mimeType: "video/mp4", extension: "mp4" };
  if (bytes.length >= 4 && bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]))) return { mediaType: "video", mimeType: "video/webm", extension: "webm" };
  return null;
}

async function ensureInitialAdmin() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const [existing] = await db.select({ id: portalAdmins.id }).from(portalAdmins).limit(1);
  if (existing) return;
  const bootstrapPassword = process.env.BOOTSTRAP_ADMIN_PASSWORD;
  if (!bootstrapPassword) {
    console.warn("[Kilas] First admin is not initialized: bootstrap secret is not configured.");
    return;
  }
  if (bootstrapPassword.length < 12) throw new Error("The initial admin password must contain at least 12 characters.");
  try {
    await db.insert(portalAdmins).values({ username: "admin", passwordHash: await passwordHash(bootstrapPassword), role: "admin" });
    console.log("[Kilas] Initial admin account provisioned.");
  } catch {
    const [afterRace] = await db.select({ id: portalAdmins.id }).from(portalAdmins).limit(1);
    if (!afterRace) throw new Error("Initial admin provisioning failed.");
  }
}

export async function registerPortalRoutes(app: Express) {
  await ensureInitialAdmin();

  app.get("/api/public/settings", endpoint(async (_req, res) => {
    res.set("Cache-Control", "no-store").json({ layout: await getStoredLayout() });
  }));

  app.get("/api/public/news", endpoint(async (_req, res) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const rows = await db.select().from(portalNews)
      .where(eq(portalNews.status, "published"))
      .orderBy(desc(portalNews.publishedAt), desc(portalNews.createdAt));
    const withMedia = await attachMedia(rows);
    res.set("Cache-Control", "no-store").json(withMedia.map(item => ({ ...item, media: item.media.map(publicAsset) })));
  }));

  app.get("/api/public/news/:slug", endpoint(async (req, res) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const [row] = await db.select().from(portalNews)
      .where(and(eq(portalNews.slug, req.params.slug), eq(portalNews.status, "published"))).limit(1);
    if (!row) { res.status(404).json({ error: "Berita tidak ditemukan." }); return; }
    const [item] = await attachMedia([row]);
    res.set("Cache-Control", "no-store").json({ ...item, media: item.media.map(publicAsset) });
  }));

  app.post("/api/admin/login", endpoint(async (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const record = attempts.get(ip);
    if (record && record.resetAt > now && record.count >= 8) {
      res.status(429).json({ error: "Terlalu banyak percobaan. Coba kembali beberapa menit lagi." }); return;
    }
    if (record && record.resetAt <= now) attempts.delete(ip);
    const username = usernameValue(req.body?.username);
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const [admin] = await db.select().from(portalAdmins).where(eq(portalAdmins.username, username)).limit(1);
    const valid = Boolean(admin && password.length <= 256 && await passwordMatches(password, admin.passwordHash));
    if (!valid || !admin) {
      const current = attempts.get(ip);
      attempts.set(ip, { count: (current?.resetAt && current.resetAt > now ? current.count : 0) + 1, resetAt: now + 15 * 60 * 1000 });
      res.status(401).json({ error: "Username atau password tidak sesuai." }); return;
    }
    attempts.delete(ip);
    const rawToken = randomBytes(32).toString("hex");
    const sessionHash = sha256(rawToken);
    const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
    await db.insert(adminSessions).values({ sessionHash, adminId: admin.id, expiresAt });
    res.setHeader("Set-Cookie", sessionCookie(rawToken));
    res.set("Cache-Control", "no-store").json({ admin: cleanAdmin(admin), csrfToken: csrfFor(rawToken) });
  }));

  app.get("/api/admin/me", endpoint(async (req, res) => {
    const session = await currentSession(req, res);
    if (!session) { res.set("Cache-Control", "no-store").json({ authenticated: false }); return; }
    res.set("Cache-Control", "no-store").json({ authenticated: true, admin: cleanAdmin(session.admin), csrfToken: csrfFor(session.rawToken) });
  }));

  app.post("/api/admin/logout", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    await db.delete(adminSessions).where(eq(adminSessions.sessionHash, session.sessionHash));
    res.setHeader("Set-Cookie", clearSessionCookie());
    res.json({ success: true });
  }));

  app.get("/api/admin/news", endpoint(async (req, res) => {
    const session = await currentSession(req, res);
    if (!session) { res.status(401).json({ error: "Silakan masuk." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const rows = await db.select().from(portalNews).orderBy(desc(portalNews.updatedAt));
    const withMedia = await attachMedia(rows);
    res.set("Cache-Control", "no-store").json(withMedia.map(item => ({ ...item, media: item.media.map(publicAsset) })));
  }));

  app.post("/api/admin/news", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const title = typeof req.body?.title === "string" ? req.body.title.trim().slice(0, 240) : "";
    const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
    if (title.length < 5 || content.length < 10) { res.status(400).json({ error: "Judul minimal 5 karakter dan isi berita minimal 10 karakter." }); return; }
    if (Buffer.byteLength(content, "utf8") > 56_000) { res.status(413).json({ error: "Isi berita terlalu panjang. Batas penyimpanan adalah 14.000 karakter." }); return; }
    const summary = typeof req.body?.summary === "string" ? req.body.summary.trim().slice(0, 1200) : "";
    const category = typeof req.body?.category === "string" ? req.body.category.trim().slice(0, 80) || "Berita" : "Berita";
    const status = req.body?.status === "published" ? "published" : "draft";
    const slug = slugify(typeof req.body?.slug === "string" && req.body.slug.trim() ? req.body.slug.trim() : title);
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    try {
      const result = await db.insert(portalNews).values({ slug, title, summary, content, category, status, mediaIds: safeMediaIds(req.body?.mediaIds), authorId: session.admin.id, publishedAt: status === "published" ? new Date() : null });
      res.status(201).json({ id: Number(result[0].insertId), success: true });
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.toLowerCase().includes("duplicate")) { res.status(409).json({ error: "Alamat berita tersebut sudah digunakan. Ubah tautan/slug." }); return; }
      throw error;
    }
  }));

  app.put("/api/admin/news/:id", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) { res.status(400).json({ error: "ID berita tidak valid." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const [current] = await db.select().from(portalNews).where(eq(portalNews.id, id)).limit(1);
    if (!current) { res.status(404).json({ error: "Berita tidak ditemukan." }); return; }
    const title = typeof req.body?.title === "string" ? req.body.title.trim().slice(0, 240) : current.title;
    const content = typeof req.body?.content === "string" ? req.body.content.trim() : current.content;
    if (title.length < 5 || content.length < 10) { res.status(400).json({ error: "Judul minimal 5 karakter dan isi berita minimal 10 karakter." }); return; }
    if (Buffer.byteLength(content, "utf8") > 56_000) { res.status(413).json({ error: "Isi berita terlalu panjang. Batas penyimpanan adalah 14.000 karakter." }); return; }
    const status = req.body?.status === "published" ? "published" : "draft";
    const slugSource = typeof req.body?.slug === "string" && req.body.slug.trim() ? req.body.slug.trim() : current.slug;
    try {
      await db.update(portalNews).set({
        slug: slugify(slugSource), title, content,
        summary: typeof req.body?.summary === "string" ? req.body.summary.trim().slice(0, 1200) : current.summary,
        category: typeof req.body?.category === "string" ? req.body.category.trim().slice(0, 80) || "Berita" : current.category,
        status, mediaIds: safeMediaIds(req.body?.mediaIds),
        publishedAt: status === "published" ? current.publishedAt ?? new Date() : current.publishedAt,
      }).where(eq(portalNews.id, id));
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.toLowerCase().includes("duplicate")) { res.status(409).json({ error: "Alamat berita tersebut sudah digunakan." }); return; }
      throw error;
    }
    res.json({ success: true });
  }));

  app.delete("/api/admin/news/:id", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) { res.status(400).json({ error: "ID berita tidak valid." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    await db.delete(portalNews).where(eq(portalNews.id, id));
    res.json({ success: true });
  }));

  app.get("/api/admin/media", endpoint(async (req, res) => {
    const session = await currentSession(req, res);
    if (!session) { res.status(401).json({ error: "Silakan masuk." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const assets = await db.select().from(mediaAssets).orderBy(desc(mediaAssets.createdAt));
    res.set("Cache-Control", "no-store").json(assets.map(publicAsset));
  }));

  app.post("/api/admin/media", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const encoded = typeof req.body?.data === "string" ? req.body.data : "";
    if (!encoded || encoded.length > Math.ceil(MAX_UPLOAD_BYTES * 4 / 3) + 16 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) {
      res.status(400).json({ error: "Berkas kosong atau melebihi batas 40 MB." }); return;
    }
    const bytes = Buffer.from(encoded, "base64");
    if (bytes.length > MAX_UPLOAD_BYTES) { res.status(413).json({ error: "Ukuran berkas maksimum 40 MB." }); return; }
    const detected = detectMedia(bytes);
    const reported = typeof req.body?.mimeType === "string" ? req.body.mimeType : "";
    if (!detected || detected.mimeType !== reported) { res.status(415).json({ error: "Format berkas tidak didukung atau tidak cocok. Gunakan JPG, PNG, WebP, GIF, MP4, atau WebM." }); return; }
    const requestedName = typeof req.body?.name === "string" ? req.body.name : `media-${Date.now()}.${detected.extension}`;
    const name = requestedName.replace(/[\\/\x00-\x1f]/g, "-").trim().slice(0, 180) || `media.${detected.extension}`;
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const upload = await storagePut(`kilas-bimais/${randomBytes(8).toString("hex")}.${detected.extension}`, bytes, detected.mimeType);
    const result = await db.insert(mediaAssets).values({ name, mediaType: detected.mediaType, mimeType: detected.mimeType, storageKey: upload.key, url: upload.url, byteSize: bytes.length, uploadedBy: session.admin.id });
    const [asset] = await db.select().from(mediaAssets).where(eq(mediaAssets.id, Number(result[0].insertId))).limit(1);
    if (!asset) throw new Error("Uploaded media record not found");
    res.status(201).json(publicAsset(asset));
  }));

  app.get("/api/admin/settings", endpoint(async (req, res) => {
    const session = await currentSession(req, res);
    if (!session) { res.status(401).json({ error: "Silakan masuk." }); return; }
    res.json({ layout: await getStoredLayout() });
  }));

  app.put("/api/admin/settings", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    if (session.admin.role !== "admin") { res.status(403).json({ error: "Hanya admin yang dapat mengubah layout situs." }); return; }
    const input = req.body?.layout ?? {};
    const layout = {
      storyLayout: ["grid", "list", "compact"].includes(input.storyLayout) ? input.storyLayout : "grid",
      showFeaturedStory: input.showFeaturedStory !== false,
      showCategoryNav: input.showCategoryNav !== false,
      compactHeader: input.compactHeader === true,
      accent: ["green", "blue", "gold"].includes(input.accent) ? input.accent : "green",
    };
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    await db.insert(siteSettings).values({ settingKey: "layout", settingValue: JSON.stringify(layout) })
      .onDuplicateKeyUpdate({ set: { settingValue: JSON.stringify(layout), updatedAt: new Date() } });
    res.json({ success: true, layout });
  }));

  app.get("/api/admin/users", endpoint(async (req, res) => {
    const session = await currentSession(req, res);
    if (!session) { res.status(401).json({ error: "Silakan masuk." }); return; }
    if (session.admin.role !== "admin") { res.status(403).json({ error: "Fitur ini khusus admin." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const users = await db.select({ id: portalAdmins.id, username: portalAdmins.username, role: portalAdmins.role, createdAt: portalAdmins.createdAt }).from(portalAdmins).orderBy(portalAdmins.username);
    res.json(users);
  }));

  app.post("/api/admin/users", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    if (session.admin.role !== "admin") { res.status(403).json({ error: "Hanya admin yang dapat menambah pengguna." }); return; }
    const username = usernameValue(req.body?.username);
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    const role = req.body?.role === "admin" ? "admin" : "editor";
    if (!validUsername(username)) { res.status(400).json({ error: "Username: 3–32 karakter, hanya huruf kecil, angka, titik, tanda hubung, atau garis bawah." }); return; }
    if (password.length < 10 || password.length > 256) { res.status(400).json({ error: "Sandi pengguna baru harus 10–256 karakter." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    try {
      const result = await db.insert(portalAdmins).values({ username, passwordHash: await passwordHash(password), role });
      res.status(201).json({ id: Number(result[0].insertId), username, role });
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.toLowerCase().includes("duplicate")) { res.status(409).json({ error: "Username sudah digunakan." }); return; }
      throw error;
    }
  }));

  app.patch("/api/admin/account", endpoint(async (req, res) => {
    const session = await currentSession(req, res, true);
    if (!session) return;
    const currentPassword = typeof req.body?.currentPassword === "string" ? req.body.currentPassword : "";
    if (!(await passwordMatches(currentPassword, session.admin.passwordHash))) { res.status(401).json({ error: "Sandi saat ini tidak sesuai." }); return; }
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const update: Partial<typeof portalAdmins.$inferInsert> = {};
    if (typeof req.body?.username === "string" && req.body.username.trim()) {
      const username = usernameValue(req.body.username);
      if (!validUsername(username)) { res.status(400).json({ error: "Username harus 3–32 karakter dan memakai huruf kecil, angka, titik, - atau _." }); return; }
      update.username = username;
    }
    if (typeof req.body?.password === "string" && req.body.password) {
      if (req.body.password.length < 12 || req.body.password.length > 256) { res.status(400).json({ error: "Sandi baru harus 12–256 karakter." }); return; }
      update.passwordHash = await passwordHash(req.body.password);
    }
    if (!Object.keys(update).length) { res.status(400).json({ error: "Masukkan username atau sandi baru." }); return; }
    try {
      await db.update(portalAdmins).set(update).where(eq(portalAdmins.id, session.admin.id));
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.toLowerCase().includes("duplicate")) { res.status(409).json({ error: "Username sudah digunakan." }); return; }
      throw error;
    }
    const [updated] = await db.select().from(portalAdmins).where(eq(portalAdmins.id, session.admin.id)).limit(1);
    res.json({ admin: updated ? cleanAdmin(updated) : null });
  }));
}
